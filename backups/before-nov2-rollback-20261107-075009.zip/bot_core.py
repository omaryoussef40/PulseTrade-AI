from __future__ import annotations
# automatedapp.py
# Streamlit + Interactive Brokers + Telegram automated options scanner
#
# Run:
#   pip install streamlit pandas numpy plotly streamlit-autorefresh ib-insync requests pytz
#   streamlit run automatedapp.py
#
# IBKR setup:
#   1) Open Trader Workstation or IB Gateway
#   2) Enable API access: Configure > API > Settings > Enable ActiveX and Socket Clients
#   3) Paper trading default port is usually 7497, live TWS is usually 7496
#   4) Keep AUTO TRADING disabled until you have tested paper trading carefully

import os
import sys
import math
import time
import json
import re
import traceback
from dataclasses import dataclass
from datetime import datetime, timedelta, time as dtime
from html import escape
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import requests
from modules.option_candle_exits import CANDLE_CLOSE_MODE, completed_option_closes, evaluate_close
from market_data import IBKRMarketDataProvider, MarketDataConfig, provider_from_ib
from strategies.pmb.candles import (
    candle_minutes, completed_live_bars, confirmation_minutes, confirmation_analysis_minutes, explicit_confirmation,
    follow_through_enabled, prepare_live_analysis,
)

IB_IMPORT_ERROR = None
try:
    import nest_asyncio
    nest_asyncio.apply()
except Exception:
    pass

try:
    from ib_insync import (
        IB,
        Stock,
        Option,
        MarketOrder,
        LimitOrder,
        StopOrder,
        ExecutionFilter,
        util,
    )
    IB_AVAILABLE = True
except Exception as exc:
    IB_AVAILABLE = False
    IB_IMPORT_ERROR = repr(exc)


# =========================
# CONFIG
# =========================

APP_NAME = "Automated Options App"
EASTERN = ZoneInfo("America/New_York")
EXPORT_DIR = "exports"
os.makedirs(EXPORT_DIR, exist_ok=True)

WATCHLIST = [
    "SPY", "QQQ", "IWM",
    "NVDA", "AAPL", "MSFT", "META", "AMZN", "GOOGL",
    "TSLA", "AMD", "PLTR", "COIN", "MSTR",
    "MU", "TSM", "MRVL",
    "JPM", "GS", "BAC",
    "NFLX", "UBER", "XOM", "COST",
    "RBLX", "HOOD", "SOFI", "RKLB", "HIMS", "CRWD",
    "SPCX", "NOK", "INTC", "ORCL"
]

MIN_SCORE = 70
MIN_CONFIDENCE = 60
MIN_RVOL = 1.5
TARGET_DELTA = 0.50
DEFAULT_OPTION_DTE = 7
DEFAULT_RISK_PER_TRADE = 250
DEFAULT_MAX_CONTRACTS = 2
DEFAULT_OPTION_FILTERS = {
    "require_live_greeks": True,
    "max_spread_pct": 10.0,
    "excellent_spread_pct": 5.0,
    "max_spread_dollars": 0.75,
    "min_abs_delta": 0.45,
    "target_abs_delta": 0.55,
    "max_abs_delta": 0.80,
    "max_theta_pct_of_mid": 12.0,
    "min_bid": 0.05,
    "min_volume": 0,
}
DEFAULT_ACCOUNT_SIZE = 1000
DEFAULT_MAX_TRADES_PER_DAY = 2
DEFAULT_TOP_N_TICKERS = 2
DEFAULT_MAX_SPEND_PER_TRADE = 250
DEFAULT_MAX_DAILY_CAPITAL = 500
DEFAULT_MIN_SCORE_UI = 70
DEFAULT_MIN_CONFIDENCE_UI = 75
DEFAULT_MIN_RVOL_UI = 1.5
DEFAULT_USE_RVOL_FILTER = False
DEFAULT_USE_RVOL_SCORE = False
DEFAULT_USE_RVOL_RANKING = False
DEFAULT_MIN_ATR_UI = 0.3
DEFAULT_ORDER_TYPE = "LIMIT"
MANUAL_ORDER_SOURCE = "manual_order"
POSITION_MANAGEMENT_AUTOMATED = "automated"
POSITION_MANAGEMENT_MONITOR_ONLY = "monitor_only"
TRADE_LOG_FILE = os.path.join(EXPORT_DIR, "trade_log.csv")
ALERT_LOG_FILE = os.path.join(EXPORT_DIR, "alert_log.csv")
ACTIVE_POSITIONS_FILE = os.path.join(EXPORT_DIR, "active_positions.json")
TRADE_LOG_EXTRA_COLUMNS = [
    "exit_reason",
    "broker_status",
    "commission",
    "sec_type",
    "multiplier",
    "broker_order_ids",
    "broker_perm_ids",
    "broker_client_ids",
    "broker_order_refs",
    "broker_liquidation_flags",
    "matched_exit_external_id",
    "matched_exit_source",
    "close_classification",
    "retest_confirmed",
    "retest_trigger_level",
    "breakout_time",
    "retest_time",
    "retest_minutes_after_breakout",
    "retest_reason",
]

# Trade management defaults for intraday 7 DTE options
DEFAULT_STOP_LOSS_PCT = 20.0
DEFAULT_TAKE_PROFIT_PCT = 30.0
PREMIUM_HEALTH_WARMUP_SECONDS = 150
PREMIUM_HEALTH_WEAK_DROP_PCT = -10.0
PREMIUM_HEALTH_UNDERLYING_TOLERANCE_PCT = -0.25
PREMIUM_HEALTH_TIGHTEN_STOP_BUFFER_PCT = 3.0
MAX_OPTION_ORDER_CHUNK_QTY = 5
DEFAULT_BREAKEVEN_TRIGGER_PCT = 15.0
DEFAULT_TRAILING_TRIGGER_PCT = 25.0
DEFAULT_TRAILING_STOP_PCT = 10.0
DEFAULT_FORCE_EXIT_TIME = dtime(15, 55)
DEFAULT_MAX_CONSECUTIVE_LOSSES = 2
DEFAULT_MAX_DAILY_DRAWDOWN_PCT = 5.0


# =========================
# DATA CLASSES
# =========================

@dataclass
class IBConfig:
    host: str
    port: int
    client_id: int
    account: str | None = None
    readonly: bool = False


@dataclass
class TelegramConfig:
    bot_token: str
    chat_id: str


# =========================
# TELEGRAM
# =========================

def send_telegram_message(cfg: TelegramConfig, text: str) -> bool:
    if not cfg.bot_token or not cfg.chat_id:
        return False

    try:
        url = f"https://api.telegram.org/bot{cfg.bot_token}/sendMessage"
        payload = {
            "chat_id": cfg.chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        response = requests.post(url, json=payload, timeout=10)
        return response.status_code == 200
    except Exception:
        return False


def format_position_closed_telegram_message(event: dict) -> str:
    symbol = escape(str(event.get("Symbol") or event.get("symbol") or ""))
    option = escape(str(event.get("Option") or event.get("option") or ""))
    reason = escape(str(event.get("Reason") or event.get("exit_reason") or "Position closed"))
    status = escape(str(event.get("Status") or event.get("status") or ""))
    qty = event.get("Quantity") or event.get("quantity") or event.get("Qty")

    pnl = _number_or_none(event.get("P/L $"))
    if pnl is None:
        pnl = _number_or_none(event.get("realized_pnl"))
    pnl_label = "Pending broker confirmation"
    if pnl is not None and math.isfinite(pnl):
        pnl_label = f"+${pnl:,.2f}" if pnl > 0 else f"-${abs(pnl):,.2f}" if pnl < 0 else "$0.00"

    entry = _number_or_none(event.get("Entry") or event.get("entry_price"))
    exit_price = _number_or_none(event.get("Current") or event.get("exit_price"))
    lines = [
        "<b>Position Closed</b>",
        f"Symbol: <b>{symbol}</b>",
    ]
    if option:
        lines.append(f"Option: <b>{option}</b>")
    if qty:
        lines.append(f"Qty: <b>{escape(str(qty))}</b>")
    lines.extend([
        f"Reason: <b>{reason}</b>",
        f"P/L: <b>{pnl_label}</b>",
    ])
    if entry is not None:
        lines.append(f"Entry: <b>${float(entry):,.2f}</b>")
    if exit_price is not None:
        lines.append(f"Exit: <b>${float(exit_price):,.2f}</b>")
    if status:
        lines.append(f"Status: {status}")
    if event.get("pnl_basis") == "broker_net":
        lines.append("P/L includes broker-reported fees.")
    return "\n".join(lines)


def send_position_closed_telegram_message(cfg: TelegramConfig, event: dict) -> bool:
    action = str(event.get("Action") or event.get("action") or "").upper()
    reason = str(event.get("Reason") or event.get("exit_reason") or "")
    status = str(event.get("Status") or event.get("status") or "")
    is_broker_closed = action == "REMOVED" and (
        "Position not found at IBKR" in reason
        or "no broker position exists" in status
    )
    if action not in {"EXIT", "EXTERNAL_CLOSE"} and not is_broker_closed and not event.get("Close Confirmed"):
        return False
    return send_telegram_message(cfg, format_position_closed_telegram_message(event))


def log_alert(row: dict):
    df = pd.DataFrame([row])
    exists = os.path.exists(ALERT_LOG_FILE)
    df.to_csv(ALERT_LOG_FILE, mode="a", index=False, header=not exists)


# =========================
# IBKR CONNECTION
# =========================

def get_ib_connection(host: str, port: int, client_id: int, readonly: bool):
    if not IB_AVAILABLE:
        raise RuntimeError(
            "ib_insync could not be imported by the Python running this app. "
            f"Python: {sys.executable} | Version: {sys.version.split()[0]} | "
            f"Import error: {IB_IMPORT_ERROR}. "
            "Install with: python -m pip install ib-insync nest-asyncio"
        )

    ib = IB()
    ib.connect(host, port, clientId=client_id, readonly=readonly, timeout=10)
    return ib


def connect_ib(cfg: IBConfig):
    return get_ib_connection(cfg.host, cfg.port, cfg.client_id, cfg.readonly)


def qualify_stock(ib: IB, symbol: str):
    """Qualify a stock contract through the central market-data provider."""
    return provider_from_ib(ib, timezone=EASTERN).qualify_stock(symbol)

def fetch_ib_intraday(ib: IB, symbol: str, duration="5 D", bar_size="5 mins") -> pd.DataFrame:
    """Fetch normalized intraday OHLCV through market_data.py.

    Kept as a compatibility wrapper so existing scanner/engine calls continue
    to work while the codebase migrates to MarketDataService.
    """
    return provider_from_ib(ib, timezone=EASTERN).intraday_bars(
        symbol=symbol,
        duration=duration,
        bar_size=bar_size,
        use_rth=True,
    )


def fetch_ib_daily(ib: IB, symbol: str, duration="20 D") -> pd.DataFrame:
    """Fetch normalized daily OHLCV through market_data.py."""
    return provider_from_ib(ib, timezone=EASTERN).daily_bars(
        symbol=symbol,
        duration=duration,
        use_rth=True,
    )


def fetch_ibkr_account_summary_dict(cfg: IBConfig) -> dict:
    """Return key account fields through market_data.py for dashboard/engine use."""
    provider = IBKRMarketDataProvider(
        MarketDataConfig(
            host=cfg.host,
            port=cfg.port,
            client_id=cfg.client_id,
            account=cfg.account,
            readonly=cfg.readonly,
            timezone=EASTERN,
        )
    )
    try:
        return provider.account_summary()
    finally:
        provider.disconnect()


def fetch_ibkr_positions_list(cfg: IBConfig) -> list[dict]:
    """Return live broker positions through market_data.py for dashboard display."""
    provider = IBKRMarketDataProvider(
        MarketDataConfig(
            host=cfg.host,
            port=cfg.port,
            client_id=cfg.client_id,
            account=cfg.account,
            readonly=True,
            timezone=EASTERN,
        )
    )
    try:
        return provider.positions()
    finally:
        provider.disconnect()


# =========================
# INDICATORS
# =========================

def calculate_vwap(df: pd.DataFrame) -> pd.Series:
    df = df.copy()
    session = pd.Series(df.index.date, index=df.index)
    typical_price = (df["High"] + df["Low"] + df["Close"]) / 3
    dollar_volume = typical_price * df["Volume"]
    cumulative_dollar_volume = dollar_volume.groupby(session).cumsum()
    cumulative_volume = df["Volume"].groupby(session).cumsum()
    return cumulative_dollar_volume / cumulative_volume.replace(0, np.nan)


def calculate_atr(df: pd.DataFrame, length=14) -> pd.Series:
    high_low = df["High"] - df["Low"]
    high_close = (df["High"] - df["Close"].shift()).abs()
    low_close = (df["Low"] - df["Close"].shift()).abs()
    true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return true_range.rolling(length).mean()


def get_valid_sessions(intraday: pd.DataFrame, min_bars=50) -> list:
    dates = sorted(set(intraday.index.date))
    valid = []
    for session_date in dates:
        session_data = intraday[intraday.index.date == session_date]
        if len(session_data) >= min_bars:
            valid.append(session_date)
    return valid


def previous_trading_day_from_daily(daily: pd.DataFrame, today_date) -> pd.Timestamp | None:
    """Return the previous completed trading session from actual IBKR daily bars.

    This intentionally does not use weekday math. If Friday is a market
    holiday, the previous trading day for Monday should be Thursday.
    If today exists as an unfinished daily bar, it is excluded by date.
    """
    if daily.empty:
        return None

    df = daily.dropna().copy()
    if "Volume" in df.columns:
        df = df[pd.to_numeric(df["Volume"], errors="coerce").fillna(0) > 0]

    daily_dates = pd.Series(pd.to_datetime(df.index).date, index=df.index)
    prior = df[daily_dates < today_date]
    if prior.empty:
        return None
    return prior.index[-1]


def previous_completed_intraday_session(intraday: pd.DataFrame, today_date, min_bars: int = 50) -> tuple | None:
    """Fallback PDH/PDL source from actual intraday sessions, not weekdays.

    Uses the last session before today that has enough RTH 5-minute bars to
    represent a completed session. This skips weekends, market holidays, and
    empty/partial data days.
    """
    if intraday.empty:
        return None

    prior_dates = []
    for session_date in sorted(set(intraday.index.date)):
        if session_date >= today_date:
            continue
        session_data = intraday[intraday.index.date == session_date]
        if len(session_data) >= min_bars and float(session_data["Volume"].sum()) > 0:
            prior_dates.append(session_date)

    if not prior_dates:
        return None

    previous_session_date = prior_dates[-1]
    previous_session = intraday[intraday.index.date == previous_session_date]
    return previous_session_date, previous_session


def calculate_rvol(intraday: pd.DataFrame, today_date) -> float:
    today_data = intraday[intraday.index.date == today_date]
    if today_data.empty:
        return 0.0

    current_time = today_data.index[-1].time()
    today_volume = float(today_data["Volume"].sum())
    previous_session_volumes = []

    for session_date in sorted(set(intraday.index.date)):
        if session_date == today_date:
            continue
        session_data = intraday[intraday.index.date == session_date]
        if len(session_data) >= 50:
            session_to_time = session_data[session_data.index.time <= current_time]
            if session_to_time.empty:
                continue
            session_volume = float(session_to_time["Volume"].sum())
            if session_volume > 0:
                previous_session_volumes.append(session_volume)

    if not previous_session_volumes:
        return 0.0

    return today_volume / (sum(previous_session_volumes) / len(previous_session_volumes))


def calculate_support_resistance(daily: pd.DataFrame, current_price: float, lookback: int = 30, pivot_window: int = 2) -> dict:
    """Return nearest support/resistance as informational context only. Does not affect scoring."""
    if daily.empty or current_price <= 0:
        return {
            "Nearest Support": None,
            "Support Distance %": None,
            "Nearest Resistance": None,
            "Resistance Distance %": None,
        }

    df = daily.tail(lookback).copy()
    if len(df) < (pivot_window * 2 + 1):
        return {
            "Nearest Support": None,
            "Support Distance %": None,
            "Nearest Resistance": None,
            "Resistance Distance %": None,
        }

    supports = []
    resistances = []

    for i in range(pivot_window, len(df) - pivot_window):
        window = df.iloc[i - pivot_window:i + pivot_window + 1]
        center = df.iloc[i]
        low = float(center["Low"])
        high = float(center["High"])

        if low == float(window["Low"].min()):
            supports.append(low)
        if high == float(window["High"].max()):
            resistances.append(high)

    support_levels = sorted([x for x in supports if x < current_price], reverse=True)
    resistance_levels = sorted([x for x in resistances if x > current_price])

    nearest_support = support_levels[0] if support_levels else None
    nearest_resistance = resistance_levels[0] if resistance_levels else None

    support_distance = ((current_price - nearest_support) / current_price * 100) if nearest_support else None
    resistance_distance = ((nearest_resistance - current_price) / current_price * 100) if nearest_resistance else None

    return {
        "Nearest Support": round(nearest_support, 2) if nearest_support else None,
        "Support Distance %": round(support_distance, 2) if support_distance is not None else None,
        "Nearest Resistance": round(nearest_resistance, 2) if nearest_resistance else None,
        "Resistance Distance %": round(resistance_distance, 2) if resistance_distance is not None else None,
    }


# =========================
# SCANNER
# =========================

def scan_symbol_ib(
    ib: IB,
    symbol: str,
    use_rvol_score: bool = False,
    strategy_name: str = "pmb",
    orb_minutes: int = 15,
    min_session_bars: int = 7,
    min_score: float | None = None,
    require_retest: bool = False,
    retest_tolerance_pct: float = 0.10,
    retest_max_minutes: int = 45,
    intraday_duration: str = "5 D",
    intraday_bar_size: str = "5 mins",
    analysis_bar_minutes: int | None = None,
    breakout_follow_through: dict | None = None,
    prepared_data: tuple[pd.DataFrame, pd.DataFrame] | None = None,
    as_of: datetime | None = None,
) -> dict | None:
    """Run the active scanner strategy on IBKR historical bars.

    PMB is the production strategy. The strategy logic lives in
    strategies/pmb/strategy.py so the live scanner and Strategy Lab can stay in
    parity. Confidence is returned only as a compatibility/debug field and is
    not used as a live trade blocker.
    """
    now = pd.Timestamp(as_of or datetime.now(EASTERN))
    analysis_minutes = confirmation_analysis_minutes(breakout_follow_through, int(analysis_bar_minutes or candle_minutes(intraday_bar_size)))
    if follow_through_enabled(breakout_follow_through) and confirmation_minutes(breakout_follow_through, analysis_minutes) == 5 and candle_minutes(intraday_bar_size) > 5:
        intraday_bar_size = "5 mins"
    raw_intraday = prepared_data[0] if prepared_data is not None else fetch_ib_intraday(ib, symbol, duration=intraday_duration, bar_size=intraday_bar_size)
    confirmation_source = completed_live_bars(raw_intraday, intraday_bar_size, None, now)
    intraday = prepare_live_analysis(
        raw_intraday, intraday_bar_size, analysis_minutes, now,
        keep_source_bars=(analysis_minutes == 5 and candle_minutes(intraday_bar_size) == 1),
    )
    daily = prepared_data[1] if prepared_data is not None else fetch_ib_daily(ib, symbol)

    if intraday.empty or len(intraday) < 50:
        return None

    def _result_session_date(result: dict | None):
        raw = str((result or {}).get("ORB Confirmation Time", "")).strip()
        if len(raw) < 10:
            return None
        try:
            return datetime.fromisoformat(raw[:10]).date()
        except Exception:
            return None

    try:
        from strategies.registry import scan_dataframe as strategy_scan_dataframe
    except Exception:
        # Fallback to PMB directly if the registry is unavailable.
        from strategies.pmb.strategy import scan_dataframe as strategy_scan_dataframe
        result = strategy_scan_dataframe(
            symbol=symbol,
            intraday=intraday,
            daily=daily,
            use_rvol_score=use_rvol_score,
            min_score=MIN_SCORE if min_score is None else float(min_score),
            timezone=EASTERN,
            orb_minutes=int(orb_minutes),
            min_session_bars=int(min_session_bars),
            require_retest=bool(require_retest),
            retest_tolerance_pct=float(retest_tolerance_pct),
            retest_max_minutes=int(retest_max_minutes),
            analysis_bar_minutes=analysis_minutes,
            breakout_follow_through=breakout_follow_through,
            confirmation_intraday=confirmation_source if explicit_confirmation(breakout_follow_through) else None,
            confirmation_source_minutes=candle_minutes(intraday_bar_size),
            as_of=now,
        )
        session_date = _result_session_date(result)
        if session_date and session_date != now.date():
            return None
        return result

    result = strategy_scan_dataframe(
        strategy_name=strategy_name or "pmb",
        symbol=symbol,
        intraday=intraday,
        daily=daily,
        use_rvol_score=use_rvol_score,
        min_score=MIN_SCORE if min_score is None else float(min_score),
        timezone=EASTERN,
        orb_minutes=int(orb_minutes),
        min_session_bars=int(min_session_bars),
        require_retest=bool(require_retest),
        retest_tolerance_pct=float(retest_tolerance_pct),
        retest_max_minutes=int(retest_max_minutes),
        analysis_bar_minutes=analysis_minutes,
        breakout_follow_through=breakout_follow_through,
        confirmation_intraday=confirmation_source if explicit_confirmation(breakout_follow_through) else None,
        confirmation_source_minutes=candle_minutes(intraday_bar_size),
        as_of=now,
    )
    session_date = _result_session_date(result)
    if session_date and session_date != now.date():
        return None
    return result


# =========================
# OPTIONS VIA IBKR
# =========================

def get_option_expiry_and_strikes(ib: IB, symbol: str, dte_target=7):
    stock = qualify_stock(ib, symbol)
    params = ib.reqSecDefOptParams(symbol, "", stock.secType, stock.conId)
    if not params:
        return None, []

    chain = next((p for p in params if p.exchange == "SMART"), params[0])
    today = datetime.now(EASTERN).date()
    target = today + timedelta(days=dte_target)

    expirations = sorted(chain.expirations)
    expiration_dates = []
    for exp in expirations:
        try:
            expiration_dates.append((exp, datetime.strptime(exp, "%Y%m%d").date()))
        except Exception:
            continue

    valid = [(raw, dt) for raw, dt in expiration_dates if dt >= today]
    if not valid:
        return None, []

    best_exp = min(valid, key=lambda item: abs((item[1] - target).days))[0]
    strikes = sorted(float(s) for s in chain.strikes if s and s > 0)
    return best_exp, strikes


def _option_chain_candidates(ib: IB, symbol: str, dte_target=7) -> list[dict]:
    """Return valid IB option chain/expiry combinations, preferring SMART."""
    stock = qualify_stock(ib, symbol)
    params = ib.reqSecDefOptParams(symbol, "", stock.secType, stock.conId)
    if not params:
        return []

    today = datetime.now(EASTERN).date()
    target = today + timedelta(days=dte_target)
    chains = sorted(
        params,
        key=lambda p: (
            0 if str(getattr(p, "exchange", "")).upper() == "SMART" else 1,
            str(getattr(p, "tradingClass", "")),
        ),
    )
    max_expiries = 3
    candidates = []
    seen = set()
    for chain in chains:
        expiration_dates = []
        for exp in sorted(getattr(chain, "expirations", []) or []):
            try:
                exp_date = datetime.strptime(exp, "%Y%m%d").date()
            except Exception:
                continue
            if exp_date >= today:
                expiration_dates.append((exp, exp_date))
        if not expiration_dates:
            continue

        expiries = sorted(expiration_dates, key=lambda item: abs((item[1] - target).days))[:max_expiries]
        strikes = sorted(float(s) for s in (getattr(chain, "strikes", []) or []) if s and s > 0)
        if not strikes:
            continue

        for expiry, expiry_date in expiries:
            key = (
                str(getattr(chain, "exchange", "")),
                str(getattr(chain, "tradingClass", "")),
                str(getattr(chain, "multiplier", "") or "100"),
                expiry,
            )
            if key in seen:
                continue
            seen.add(key)
            candidates.append({
                "exchange": str(getattr(chain, "exchange", "") or "SMART"),
                "tradingClass": str(getattr(chain, "tradingClass", "") or ""),
                "multiplier": str(getattr(chain, "multiplier", "") or "100"),
                "expiry": expiry,
                "expiry_date": expiry_date,
                "strikes": strikes,
                "dte_distance": abs((expiry_date - target).days),
            })
    return candidates


def _rank_option_strikes(strikes: list[float], stock_price: float, option_type: str, filters: dict) -> list[tuple[float, float, float, float]]:
    min_abs_delta = float(filters.get("min_abs_delta", 0.45))
    target_abs_delta = float(filters.get("target_abs_delta", 0.55))
    max_abs_delta = float(filters.get("max_abs_delta", 0.80))
    max_contract_cost = _finite_number(filters.get("_max_contract_cost"))
    max_checks = int(filters.get("max_contract_checks", 36) or 36)

    nearby = [s for s in strikes if stock_price * 0.80 <= s <= stock_price * 1.20]
    if not nearby:
        nearby = [s for s in strikes if stock_price * 0.70 <= s <= stock_price * 1.30]
    ranked = []
    for strike in nearby:
        est_delta = estimate_delta(option_type, strike, stock_price)
        abs_delta = abs(est_delta)
        if abs_delta < max(0.10, min_abs_delta - 0.12) or abs_delta > min(0.95, max_abs_delta + 0.08):
            continue
        delta_distance = abs(abs_delta - target_abs_delta)
        strike_distance = abs(strike - stock_price)
        affordability_bias = 0.0
        if max_contract_cost:
            if option_type == "CALL" and strike >= stock_price:
                affordability_bias = -0.20
            elif option_type == "PUT" and strike <= stock_price:
                affordability_bias = -0.20
        ranked.append((delta_distance + affordability_bias, strike_distance, strike, est_delta))

    ranked = sorted(ranked)
    if len(ranked) > max_checks:
        return ranked[:max_checks]
    return ranked


def estimate_delta(option_type: str, strike: float, stock_price: float) -> float:
    distance_pct = (strike - stock_price) / stock_price
    if option_type == "CALL":
        delta = 0.50 - (distance_pct * 5)
        return max(0.10, min(0.90, delta))
    delta = -0.50 - (distance_pct * 5)
    return max(-0.90, min(-0.10, delta))


def get_snapshot_mid(ib: IB, contract) -> dict:
    ticker = ib.reqMktData(contract, "", snapshot=True, regulatorySnapshot=False)
    is_option_contract = str(getattr(contract, "secType", "") or "").upper() in {"OPT", "FOP"}
    deadline = time.time() + 3
    while time.time() < deadline:
        ib.sleep(0.25)
        has_quote = (ticker.bid and ticker.bid > 0) or (ticker.ask and ticker.ask > 0) or (ticker.last and ticker.last > 0)
        has_greeks = bool(ticker.modelGreeks or ticker.bidGreeks or ticker.askGreeks or ticker.lastGreeks)
        if has_greeks or (has_quote and not is_option_contract):
            break

    bid = ticker.bid if ticker.bid and ticker.bid > 0 else np.nan
    ask = ticker.ask if ticker.ask and ticker.ask > 0 else np.nan
    last = ticker.last if ticker.last and ticker.last > 0 else np.nan

    if not np.isnan(bid) and not np.isnan(ask):
        mid = (bid + ask) / 2
        spread_pct = (ask - bid) / mid if mid else np.nan
    elif not np.isnan(last):
        mid = last
        spread_pct = np.nan
    else:
        mid = np.nan
        spread_pct = np.nan

    greek_source = ""
    greeks = ticker.modelGreeks or ticker.bidGreeks or ticker.askGreeks or ticker.lastGreeks
    if ticker.modelGreeks:
        greek_source = "model"
    elif ticker.bidGreeks:
        greek_source = "bid"
    elif ticker.askGreeks:
        greek_source = "ask"
    elif ticker.lastGreeks:
        greek_source = "last"

    return {
        "Bid": bid,
        "Ask": ask,
        "Last": last,
        "Mid": mid,
        "Market Data Type": getattr(ticker, "marketDataType", None),
        "Quote Time": getattr(ticker, "time", None),
        "Model Price": getattr(greeks, "optPrice", np.nan) if greeks else np.nan,
        "Spread %": spread_pct,
        "Volume": ticker.volume if ticker.volume else 0,
        "Delta": getattr(greeks, "delta", np.nan) if greeks else np.nan,
        "Gamma": getattr(greeks, "gamma", np.nan) if greeks else np.nan,
        "Theta": getattr(greeks, "theta", np.nan) if greeks else np.nan,
        "Vega": getattr(greeks, "vega", np.nan) if greeks else np.nan,
        "Implied Vol": getattr(greeks, "impliedVol", np.nan) if greeks else np.nan,
        "Greek Source": greek_source,
    }


def get_stock_snapshot_price(ib: IB, symbol: str) -> float | None:
    """Return a quick stock mark using last/market price, then bid/ask midpoint."""
    if not symbol:
        return None
    contract = Stock(str(symbol).upper(), "SMART", "USD")
    try:
        qualified = ib.qualifyContracts(contract)
        if qualified:
            contract = qualified[0]
    except Exception:
        pass

    ticker = ib.reqMktData(contract, "", snapshot=True, regulatorySnapshot=False)
    deadline = time.time() + 3
    while time.time() < deadline:
        ib.sleep(0.25)
        values = [
            getattr(ticker, "marketPrice", lambda: np.nan)(),
            getattr(ticker, "last", np.nan),
            getattr(ticker, "close", np.nan),
        ]
        if any(_finite_number(value) for value in values):
            break

    market_price = _finite_number(getattr(ticker, "marketPrice", lambda: np.nan)())
    if market_price and market_price > 0:
        return market_price
    last = _finite_number(getattr(ticker, "last", np.nan))
    if last and last > 0:
        return last
    bid = _finite_number(getattr(ticker, "bid", np.nan))
    ask = _finite_number(getattr(ticker, "ask", np.nan))
    if bid and ask and bid > 0 and ask > 0:
        return (bid + ask) / 2.0
    close = _finite_number(getattr(ticker, "close", np.nan))
    if close and close > 0:
        return close
    return None


def _finite_number(value) -> float | None:
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return None
    return numeric if np.isfinite(numeric) else None


def option_filters_from_config(config: dict | None = None) -> dict:
    filters = dict(DEFAULT_OPTION_FILTERS)
    if isinstance(config, dict):
        raw = config.get("option_filters", {})
        if isinstance(raw, dict):
            filters.update(raw)
    return filters


def rate_option_delta(delta, signal: str, filters: dict | None = None) -> dict:
    """Rate a live option delta against the configured strategy range and target."""
    filters = option_filters_from_config({"option_filters": filters or {}})
    min_delta = float(filters.get("min_abs_delta", 0.45))
    target_delta = float(filters.get("target_abs_delta", 0.55))
    max_delta = float(filters.get("max_abs_delta", 0.80))
    live_delta = _finite_number(delta)
    if live_delta is None:
        return {
            "label": "Unavailable",
            "score": None,
            "detail": "IBKR did not return a live delta.",
            "target": target_delta,
            "minimum": min_delta,
            "maximum": max_delta,
        }

    expected_sign = 1 if str(signal or "").upper() == "CALL" else -1
    if live_delta * expected_sign <= 0:
        return {
            "label": "Weak",
            "score": 0,
            "detail": f"Delta sign does not match the selected {str(signal or '').upper()} side.",
            "delta": round(live_delta, 4),
            "target": target_delta,
            "minimum": min_delta,
            "maximum": max_delta,
        }

    abs_delta = abs(live_delta)
    if abs_delta < target_delta:
        target_span = max(target_delta - min_delta, 0.01)
    else:
        target_span = max(max_delta - target_delta, 0.01)
    target_distance = abs(abs_delta - target_delta)

    if min_delta <= abs_delta <= max_delta:
        score = round(max(80.0, 100.0 - 20.0 * (target_distance / target_span)))
        detail = (
            f"Within the strategy range {min_delta:.2f}-{max_delta:.2f}; "
            f"target is {target_delta:.2f}."
        )
    else:
        nearest_boundary = min_delta if abs_delta < min_delta else max_delta
        outside_distance = abs(abs_delta - nearest_boundary)
        score = round(max(0.0, 80.0 - 80.0 * (outside_distance / 0.15)))
        direction = "below" if abs_delta < min_delta else "above"
        detail = (
            f"Outside the strategy range {min_delta:.2f}-{max_delta:.2f}; "
            f"|delta| is {direction} the allowed range."
        )

    label = "Excellent" if score >= 90 else "Good" if score >= 75 else "Fair" if score >= 50 else "Weak"
    return {
        "label": label,
        "score": int(score),
        "detail": detail,
        "delta": round(live_delta, 4),
        "absolute_delta": round(abs_delta, 4),
        "target": target_delta,
        "minimum": min_delta,
        "maximum": max_delta,
    }


def _option_quality_score(option: dict, filters: dict) -> tuple[int, str]:
    score = 0
    notes = []

    spread_pct = _finite_number(option.get("Spread %"))
    excellent_spread = float(filters.get("excellent_spread_pct", 5.0))
    max_spread = float(filters.get("max_spread_pct", 10.0))
    if spread_pct is not None:
        if spread_pct <= excellent_spread:
            score += 35
            notes.append(f"tight spread {spread_pct:.1f}%")
        elif spread_pct <= max_spread:
            score += 25
            notes.append(f"acceptable spread {spread_pct:.1f}%")
        else:
            notes.append(f"wide spread {spread_pct:.1f}%")

    abs_delta = abs(float(option.get("Delta") or 0))
    min_delta = float(filters.get("min_abs_delta", 0.45))
    target_delta = float(filters.get("target_abs_delta", 0.55))
    max_delta = float(filters.get("max_abs_delta", 0.80))
    if min_delta <= abs_delta <= max_delta:
        distance = abs(abs_delta - target_delta)
        score += max(0, int(round(30 - min(distance / max(target_delta - min_delta, 0.01), 1.0) * 10)))
        notes.append(f"delta {abs_delta:.2f}")

    mid = _finite_number(option.get("Mid"))
    theta = _finite_number(option.get("Theta"))
    max_theta_pct = float(filters.get("max_theta_pct_of_mid", 12.0))
    if mid and theta is not None:
        theta_pct = abs(theta) / mid * 100
        option["Theta % Mid"] = round(theta_pct, 1)
        if theta_pct <= max_theta_pct * 0.5:
            score += 15
            notes.append(f"low theta {theta_pct:.1f}%")
        elif theta_pct <= max_theta_pct:
            score += 10
            notes.append(f"ok theta {theta_pct:.1f}%")
        else:
            notes.append(f"high theta {theta_pct:.1f}%")

    gamma = _finite_number(option.get("Gamma"))
    if gamma is not None and gamma > 0:
        score += 10
        notes.append("positive gamma")

    volume = _finite_number(option.get("Volume")) or 0
    if volume >= max(1, int(filters.get("min_volume", 0))):
        score += 10
        notes.append(f"volume {int(volume)}")
    elif int(filters.get("min_volume", 0)) <= 0:
        score += 5

    return min(score, 100), " | ".join(notes)


def recommend_option_ib(ib: IB, symbol: str, signal: str, stock_price: float, dte_target=7, option_filters: dict | None = None, *, prepared_option: dict | None = None, include_alternatives: bool = False) -> dict | None:
    if signal not in ["CALL", "PUT"]:
        return None

    filters = option_filters_from_config({"option_filters": option_filters or {}})
    if prepared_option is not None:
        # Only reuse contract discovery. Prices, spread, Greeks, volume, and
        # affordability are validated again below against a fresh IBKR quote.
        if prepared_option.get("Type") != signal:
            return None
        chain_candidates = []
        seen_prepared = set()
        for candidate in [prepared_option] + list(prepared_option.get("Prepared Alternatives", []))[:2]:
            if candidate.get("Type") != signal:
                continue
            expiry = str(candidate.get("Expiry") or "")
            if len(expiry) != 8 or expiry < datetime.now(EASTERN).strftime("%Y%m%d"):
                continue
            key = (expiry, float(candidate["Strike"]), candidate.get("Trading Class", ""))
            if key in seen_prepared:
                continue
            seen_prepared.add(key)
            chain_candidates.append({"expiry": expiry, "strikes": [key[1]],
                                     "multiplier": "100", "exchange": "SMART",
                                     "tradingClass": key[2]})
    else:
        chain_candidates = _option_chain_candidates(ib, symbol, dte_target)
    if not chain_candidates:
        return None

    right = "C" if signal == "CALL" else "P"
    option_type = "CALL" if signal == "CALL" else "PUT"

    # Start with strikes close to target estimated delta to reduce API calls,
    # then require real IBKR Greeks before a contract can be selected.
    option_rows = []
    rejects: dict[str, int] = {}
    qualification_checks = 0
    market_checks = 0
    max_qualification_checks = int(filters.get("max_contract_qualification_checks", 72) or 72)
    max_market_checks = int(filters.get("max_market_data_checks", 48) or 48)

    def reject(reason: str) -> None:
        rejects[reason] = rejects.get(reason, 0) + 1

    for chain in chain_candidates:
        if qualification_checks >= max_qualification_checks or market_checks >= max_market_checks:
            break
        expiry = chain["expiry"]
        candidates = _rank_option_strikes(chain["strikes"], stock_price, option_type, filters)
        if not candidates:
            reject("no nearby strikes")
            continue

        for _, strike_distance, strike, est_delta in candidates:
            if qualification_checks >= max_qualification_checks or market_checks >= max_market_checks:
                break
            contract = Option(
                symbol,
                expiry,
                strike,
                right,
                "SMART",
                currency="USD",
                multiplier=str(chain.get("multiplier") or "100"),
                tradingClass=str(chain.get("tradingClass") or ""),
            )
            try:
                qualification_checks += 1
                qualified = ib.qualifyContracts(contract)
            except Exception:
                reject("contract qualification error")
                continue
            if not qualified:
                reject("contract not qualified")
                continue
            contract = qualified[0]
            market_checks += 1
            market = get_snapshot_mid(ib, contract)
            if prepared_option is not None:
                quote_time = market.get("Quote Time")
                if market.get("Market Data Type") != 1 or not isinstance(quote_time, datetime) or quote_time.tzinfo is None or not 0 <= (datetime.now(EASTERN) - quote_time).total_seconds() <= 15:
                    reject("fresh live option quote required")
                    continue
            mid = _finite_number(market.get("Mid"))
            bid = _finite_number(market.get("Bid"))
            ask = _finite_number(market.get("Ask"))

            if mid is None or mid <= 0 or bid is None or ask is None:
                reject("no bid/ask quote")
                continue

            spread_pct = _finite_number(market.get("Spread %"))
            spread_dollars = (ask - bid) if ask is not None and bid is not None else None
            max_spread_pct = float(filters.get("max_spread_pct", 10.0)) / 100.0
            max_spread_dollars = float(filters.get("max_spread_dollars", 0.75) or 0)
            min_bid = float(filters.get("min_bid", 0.05) or 0)
            if spread_pct is None or spread_pct > max_spread_pct:
                reject("spread percent too wide")
                continue
            if max_spread_dollars > 0 and spread_dollars is not None and spread_dollars > max_spread_dollars:
                reject("spread dollars too wide")
                continue
            if bid < min_bid:
                reject("bid below minimum")
                continue

            real_delta = _finite_number(market.get("Delta"))
            require_live_greeks = bool(filters.get("require_live_greeks", True))
            if real_delta is None:
                if require_live_greeks:
                    reject("missing live greeks")
                    continue
                real_delta = est_delta
            min_abs_delta = float(filters.get("min_abs_delta", 0.45))
            max_abs_delta = float(filters.get("max_abs_delta", 0.80))
            if signal == "CALL" and real_delta <= 0:
                reject("wrong delta sign")
                continue
            if signal == "PUT" and real_delta >= 0:
                reject("wrong delta sign")
                continue
            if abs(real_delta) < min_abs_delta or abs(real_delta) > max_abs_delta:
                reject("delta outside range")
                continue

            last = _finite_number(market.get("Last"))
            volume = _finite_number(market.get("Volume")) or 0
            min_volume = int(filters.get("min_volume", 0) or 0)
            if min_volume > 0 and volume < min_volume:
                reject("volume below minimum")
                continue

            row = {
                "Contract": contract,
                "ConId": getattr(contract, "conId", None),
                "Option": f"{symbol} {expiry} {strike:g} {option_type}",
                "Expiry": expiry,
                "Strike": strike,
                "Type": option_type,
                "Delta": round(real_delta, 4),
                "Estimated Delta": round(est_delta, 2),
                "Gamma": round(float(market.get("Gamma")), 6) if _finite_number(market.get("Gamma")) is not None else None,
                "Theta": round(float(market.get("Theta")), 6) if _finite_number(market.get("Theta")) is not None else None,
                "Vega": round(float(market.get("Vega")), 6) if _finite_number(market.get("Vega")) is not None else None,
                "Implied Vol": round(float(market.get("Implied Vol")), 4) if _finite_number(market.get("Implied Vol")) is not None else None,
                "Greek Source": market.get("Greek Source"),
                "Bid": round(bid, 2) if bid is not None else None,
                "Ask": round(ask, 2) if ask is not None else None,
                "Last": round(last, 2) if last is not None else None,
                "Mid": round(mid, 2),
                "Spread %": round(spread_pct * 100, 1) if spread_pct is not None else None,
                "Spread $": round(spread_dollars, 2) if spread_dollars is not None else None,
                "Volume": int(volume),
                "Risk / Contract": round(mid * 100, 2),
                "Strike Distance": strike_distance,
                "Chain Exchange": chain.get("exchange"),
                "Trading Class": chain.get("tradingClass"),
            }
            row["Option Score"], row["Option Score Notes"] = _option_quality_score(row, filters)
            option_rows.append(row)

    if not option_rows:
        return None

    df = pd.DataFrame(option_rows)
    target_abs_delta = float(filters.get("target_abs_delta", 0.55))
    df["Delta Distance"] = df["Delta"].apply(lambda d: abs(abs(float(d)) - target_abs_delta))
    max_contract_cost = _finite_number(filters.get("_max_contract_cost"))
    if max_contract_cost:
        df["Affordable"] = df["Risk / Contract"].apply(lambda cost: float(cost) <= max_contract_cost)
    else:
        df["Affordable"] = True
    df = df.sort_values(
        ["Affordable", "Option Score", "Delta Distance", "Risk / Contract", "Spread %", "Strike Distance"],
        ascending=[False, False, True, True, True, True],
        na_position="last",
    )
    best = df.iloc[0].to_dict()
    if include_alternatives:
        best["Prepared Alternatives"] = [
            {key: value for key, value in row.items() if key != "Contract"}
            for row in df.iloc[1:3].to_dict("records")
        ]
    if rejects:
        best["Reject Summary"] = "; ".join(f"{reason}: {count}" for reason, count in sorted(rejects.items()))
    return best


# =========================
# ORDER PLACEMENT
# =========================

def calculate_contract_quantity(mid_price: float, max_spend_per_trade: float, max_contracts: int) -> int:
    """Return how many option contracts fit inside the allowed dollar spend."""
    if not mid_price or mid_price <= 0:
        return 0
    per_contract_cost = mid_price * 100
    qty = math.floor(max_spend_per_trade / per_contract_cost)
    return max(0, min(qty, max_contracts))


def _option_risk_rows(frame):
    """Keep legacy option rows, excluding explicitly identified stock fills."""
    if 'sec_type' in frame.columns:
        types=frame['sec_type'].fillna('').astype(str).str.upper().str.strip()
        frame=frame.loc[types.isin(['','OPT','FOP'])]
    if 'strategy_profile' in frame.columns:
        frame=frame.loc[frame['strategy_profile'].fillna('')!='pine_stocks']
    return frame


def get_today_trade_stats() -> tuple[int, float]:
    """Read local trade log and return today's trade count and deployed capital."""
    if not os.path.exists(TRADE_LOG_FILE):
        return 0, 0.0

    try:
        df = _option_risk_rows(pd.read_csv(TRADE_LOG_FILE))
        if df.empty or "timestamp" not in df.columns:
            return 0, 0.0

        df["timestamp"] = _parse_timestamps_utc(df["timestamp"])
        today_et = datetime.now(EASTERN).date()
        today_df = df[df["timestamp"].dt.tz_convert(EASTERN).dt.date == today_et]

        if today_df.empty:
            return 0, 0.0

        if "event" in today_df.columns:
            today_df = today_df[today_df["event"].fillna("").astype(str).str.upper() == "ENTRY"]
        if "status" in today_df.columns:
            active_statuses = {"filled", "partiallyfilled", "submitted", "presubmitted"}
            today_df = today_df[today_df["status"].fillna("").astype(str).str.lower().isin(active_statuses)]
        if today_df.empty:
            return 0, 0.0

        def row_deployed(row: pd.Series) -> float:
            filled_qty = pd.to_numeric(pd.Series([row.get("filled_quantity")]), errors="coerce").fillna(0).iloc[0]
            entry_price = pd.to_numeric(pd.Series([row.get("entry_price")]), errors="coerce").fillna(0).iloc[0]
            if filled_qty > 0 and entry_price > 0:
                return float(filled_qty * entry_price * 100)
            estimated = pd.to_numeric(pd.Series([row.get("estimated_cost")]), errors="coerce").fillna(0).iloc[0]
            if estimated > 0:
                return float(estimated)
            quantity = pd.to_numeric(pd.Series([row.get("quantity")]), errors="coerce").fillna(0).iloc[0]
            limit_price = pd.to_numeric(pd.Series([row.get("limit_price")]), errors="coerce").fillna(0).iloc[0]
            if quantity > 0 and limit_price > 0:
                return float(quantity * limit_price * 100)
            return 0.0

        # A live order is logged immediately by the bot and then again by IBKR
        # execution sync. Collapse those near-simultaneous duplicate ENTRY rows.
        deduped: list[dict] = []
        today_df = today_df.sort_values("timestamp")
        for _, row in today_df.iterrows():
            row_time = row["timestamp"]
            key = (
                str(row.get("symbol", "")).upper(),
                str(row.get("signal", "")).upper(),
            )
            deployed_value = row_deployed(row)
            matched = False
            for item in deduped:
                seconds_apart = abs((row_time - item["timestamp"]).total_seconds())
                if item["key"] == key and seconds_apart <= 120:
                    item["deployed"] = max(float(item["deployed"]), deployed_value)
                    matched = True
                    break
            if not matched:
                deduped.append({"key": key, "timestamp": row_time, "deployed": deployed_value})

        trade_count = len(deduped)
        deployed = float(sum(item["deployed"] for item in deduped))
        return trade_count, deployed
    except Exception:
        return 0, 0.0


def get_today_traded_symbols() -> set[str]:
    """Return tickers with a successful or working entry logged today in ET."""
    if not os.path.exists(TRADE_LOG_FILE):
        return set()
    try:
        df = _option_risk_rows(pd.read_csv(TRADE_LOG_FILE))
        if df.empty or "timestamp" not in df.columns or "symbol" not in df.columns:
            return set()
        timestamps = _parse_timestamps_utc(df["timestamp"])
        valid = timestamps.notna()
        if not valid.any():
            return set()
        df = df.loc[valid].copy()
        df["_timestamp"] = timestamps.loc[valid]
        today_et = datetime.now(EASTERN).date()
        df = df[df["_timestamp"].dt.tz_convert(EASTERN).dt.date == today_et]
        if "event" in df.columns:
            df = df[df["event"].fillna("").astype(str).str.upper() == "ENTRY"]
        if "status" in df.columns:
            accepted_statuses = {"filled", "partiallyfilled", "submitted", "presubmitted"}
            df = df[df["status"].fillna("").astype(str).str.lower().isin(accepted_statuses)]
        if not df.empty:
            manual_entries = df.apply(lambda row: is_manual_order_metadata(row.to_dict()), axis=1)
            df = df[~manual_entries]
        return {
            str(symbol).strip().upper()
            for symbol in df["symbol"].dropna()
            if str(symbol).strip()
        }
    except Exception:
        return set()


def get_open_position_deployed(count_prior_day_positions: bool = True) -> float:
    """Return entry-cost exposure included in the option allocation budget.

    Unknown entry dates remain counted; known prior New York dates may be excluded.
    This changes sizing only, never broker holdings or exit ownership.
    """
    deployed = 0.0
    for pos in read_active_positions():
        if not count_prior_day_positions and is_prior_session_position(pos):
            continue
        qty = _number_or_none(pos.get("quantity")) or 0
        entry_price = _number_or_none(pos.get("entry_price")) or 0
        if qty > 0 and entry_price > 0:
            deployed += float(qty) * float(entry_price) * 100.0
    return float(deployed)


def opportunity_rank_score(result: dict, option: dict | None, use_rvol_ranking: bool = False) -> float:
    """Composite score used to choose only the best tickers of the day."""
    option_score = float(option.get("Option Score", 0)) if option else 0.0
    rvol_component = min(float(result.get("RVOL", 0)) * 10, 30) if use_rvol_ranking else 0
    atr_component = min(float(result.get("ATR %", 0)) * 10, 15)
    sr_component = setup_room_score(result)

    return round(
        float(result.get("Score", 0)) * 0.60
        + option_score * 0.25
        + atr_component
        + sr_component
        + rvol_component,
        2,
    )


def setup_room_check(result: dict, min_room_pct: float = 0.75) -> tuple[bool, float | None, str]:
    """Check whether a setup has enough distance to the next opposing level."""
    signal = str(result.get("Signal", "")).upper()
    try:
        if signal == "CALL":
            room = result.get("Resistance Distance %")
            if room is None or pd.isna(room):
                return True, None, "No nearby resistance above price"
            room = float(room)
            if room < float(min_room_pct):
                return False, room, f"Resistance too close ({room:.2f}% < {float(min_room_pct):.2f}%)"
            return True, room, f"Upside room to resistance: {room:.2f}%"
        if signal == "PUT":
            room = result.get("Support Distance %")
            if room is None or pd.isna(room):
                return True, None, "No nearby support below price"
            room = float(room)
            if room < float(min_room_pct):
                return False, room, f"Support too close ({room:.2f}% < {float(min_room_pct):.2f}%)"
            return True, room, f"Downside room to support: {room:.2f}%"
    except Exception:
        return False, None, "Could not validate support/resistance room"
    return False, None, "No directional signal for room check"


def setup_room_score(result: dict, max_points: float = 10.0) -> float:
    """Reward setups that have clean space before the next support/resistance level."""
    ok, room, _note = setup_room_check(result, 0.0)
    if not ok:
        return 0.0
    if room is None:
        return float(max_points)
    return round(min(max(float(room), 0.0) * 4.0, float(max_points)), 2)


def place_option_order(
    ib: IB,
    option_contract,
    action: str,
    quantity: int,
    order_type: str,
    limit_price: float | None,
    account: str | None = None,
    max_wait_seconds: int = 60,
):
    if str(action).upper() == "SELL":
        position = {
            "con_id": getattr(option_contract, "conId", None),
            "symbol": getattr(option_contract, "symbol", ""),
            "expiry": getattr(option_contract, "lastTradeDateOrContractMonth", ""),
            "strike": getattr(option_contract, "strike", None),
            "signal": "CALL" if getattr(option_contract, "right", "") == "C" else "PUT",
        }
        assert_position_exit_allowed(position)
    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero")

    if order_type == "MARKET":
        order = MarketOrder(action, quantity)
    else:
        if limit_price is None or limit_price <= 0:
            raise ValueError("Limit price must be greater than zero")
        order = LimitOrder(action, quantity, round(limit_price, 2))

    if account:
        order.account = account

    submitted_at = datetime.now(EASTERN)
    trade = ib.placeOrder(option_contract, order)
    execution_fills = []
    for attempt in range(max(0, int(max_wait_seconds))):
        ib.sleep(1)
        status = str(getattr(trade.orderStatus, "status", "") or "")
        filled = float(getattr(trade.orderStatus, "filled", 0) or 0)
        remaining = float(getattr(trade.orderStatus, "remaining", quantity) or 0)
        if attempt % 3 == 0 or status.lower() in {"cancelled", "canceled", "apicancelled", "inactive"}:
            execution_fills = recent_contract_execution_fills(
                ib,
                option_contract,
                action=action,
                account=account,
                since=submitted_at - timedelta(seconds=5),
            )
        execution_qty = sum(float(getattr(getattr(fill, "execution", None), "shares", 0) or 0) for fill in execution_fills)
        if filled >= quantity or execution_qty >= quantity or status.lower() == "filled":
            break
        if filled > 0 and remaining <= 0:
            break
    setattr(trade, "pulse_execution_fills", execution_fills)
    return trade


def recent_contract_execution_fills(
    ib: IB,
    option_contract,
    action: str,
    account: str | None = None,
    since: datetime | None = None,
) -> list:
    """Fetch recent IBKR executions for the same contract/action.

    IBKR orderStatus can briefly report Cancelled/Inactive while executions are
    still the real source of truth. This helper lets entry logging prefer fills.
    """
    since = since or (datetime.now(EASTERN) - timedelta(minutes=5))
    if since.tzinfo is None:
        since = since.replace(tzinfo=EASTERN)
    else:
        since = since.astimezone(EASTERN)

    filt = ExecutionFilter()
    filt.time = since.strftime("%Y%m%d %H:%M:%S")
    if account:
        filt.acctCode = account

    try:
        fills = ib.reqExecutions(filt)
    except Exception:
        return []

    target_con_id = getattr(option_contract, "conId", None)
    target_symbol = str(getattr(option_contract, "localSymbol", "") or getattr(option_contract, "symbol", "") or "")
    wanted_sides = {"BOT", "BUY"} if str(action).upper() == "BUY" else {"SLD", "SELL"}
    matched = []
    for fill in fills or []:
        contract = getattr(fill, "contract", None)
        execution = getattr(fill, "execution", None)
        if contract is None or execution is None:
            continue
        if account and getattr(execution, "acctNumber", None) and getattr(execution, "acctNumber", None) != account:
            continue
        side = str(getattr(execution, "side", "") or "").upper()
        if side not in wanted_sides:
            continue
        con_id = getattr(contract, "conId", None)
        local_symbol = str(getattr(contract, "localSymbol", "") or getattr(contract, "symbol", "") or "")
        same_con_id = False
        try:
            same_con_id = bool(target_con_id and con_id and int(float(con_id)) == int(float(target_con_id)))
        except Exception:
            same_con_id = False
        if same_con_id:
            matched.append(fill)
        elif target_symbol and local_symbol and target_symbol == local_symbol:
            matched.append(fill)
    return matched


def trade_fill_details(trade, requested_quantity: int, fallback_price: float | None = None) -> dict:
    """Normalize IBKR order status using fills first, then status text."""
    order_status = getattr(trade, "orderStatus", None)
    raw_status = str(getattr(order_status, "status", "") or "")
    filled_qty = float(getattr(order_status, "filled", 0) or 0)
    remaining_qty = float(getattr(order_status, "remaining", max(int(requested_quantity), 0)) or 0)
    avg_fill_price = float(getattr(order_status, "avgFillPrice", 0) or 0)

    fills = list(getattr(trade, "fills", []) or []) + list(getattr(trade, "pulse_execution_fills", []) or [])
    if fills:
        fill_qty = 0.0
        fill_value = 0.0
        seen_exec_ids = set()
        for fill in fills:
            execution = getattr(fill, "execution", None)
            exec_id = str(getattr(execution, "execId", "") or "")
            if exec_id and exec_id in seen_exec_ids:
                continue
            if exec_id:
                seen_exec_ids.add(exec_id)
            shares = float(getattr(execution, "shares", 0) or 0)
            price = float(getattr(execution, "price", 0) or 0)
            fill_qty += shares
            fill_value += shares * price
        if fill_qty > 0:
            filled_qty = max(filled_qty, fill_qty)
            avg_fill_price = fill_value / fill_qty if fill_value else avg_fill_price

    if filled_qty > 0:
        status = "Filled" if filled_qty >= int(requested_quantity) or remaining_qty <= 0 else "PartiallyFilled"
    else:
        status = raw_status or "Submitted"

    if avg_fill_price <= 0 and fallback_price is not None:
        avg_fill_price = float(fallback_price or 0)

    return {
        "status": status,
        "raw_status": raw_status,
        "filled_qty": int(filled_qty) if float(filled_qty).is_integer() else filled_qty,
        "remaining_qty": int(remaining_qty) if float(remaining_qty).is_integer() else remaining_qty,
        "avg_fill_price": round(float(avg_fill_price), 4) if avg_fill_price else None,
    }


def log_trade(row: dict):
    exists = os.path.exists(TRADE_LOG_FILE)
    for column in TRADE_LOG_EXTRA_COLUMNS:
        row.setdefault(column, None)
    columns = None
    if exists:
        try:
            columns = list(pd.read_csv(TRADE_LOG_FILE, nrows=0).columns)
        except Exception:
            columns = None
    if columns:
        expanded_columns = list(columns)
        for column in list(row.keys()) + TRADE_LOG_EXTRA_COLUMNS:
            if column not in expanded_columns:
                expanded_columns.append(column)
        if expanded_columns != columns:
            try:
                existing = pd.read_csv(TRADE_LOG_FILE)
                for column in expanded_columns:
                    if column not in existing.columns:
                        existing[column] = None
                existing = existing[expanded_columns]
                existing.to_csv(TRADE_LOG_FILE, index=False)
                columns = expanded_columns
            except Exception:
                columns = expanded_columns
        row = {column: row.get(column) for column in columns}
    df = pd.DataFrame([row])
    broker_ids_present = bool(str(row.get("broker_order_ids") or "").strip() or str(row.get("broker_perm_ids") or "").strip())
    if exists and str(row.get("event") or "").upper() in {"ENTRY", "EXIT"} and broker_ids_present:
        try:
            from modules.performance_metrics import deduplicate_broker_event_rows
            existing_df = pd.read_csv(TRADE_LOG_FILE, low_memory=False)
            combined = deduplicate_broker_event_rows(pd.concat([existing_df, df], ignore_index=True, sort=False))
            combined.to_csv(TRADE_LOG_FILE, index=False)
            return
        except Exception:
            pass
    df.to_csv(TRADE_LOG_FILE, mode="a", index=False, header=not exists)


def sync_today_executions_to_trade_log(ib: IB, account: str | None = None, target_date=None) -> tuple[int, str]:
    """Import IBKR executions for one ET date into the local journal.

    Gateway exposes recent executions before Flex statements are available.
    Rows are grouped by option contract and side so partial fills become one
    entry/exit row in the performance journal.
    """
    if not IB_AVAILABLE:
        return 0, "IBKR API is not available."

    target_date = target_date or datetime.now(EASTERN).date()
    if hasattr(target_date, "date"):
        target_date = target_date.date()

    filt = ExecutionFilter()
    filt.time = datetime.combine(target_date, datetime.min.time(), tzinfo=EASTERN).strftime("%Y%m%d %H:%M:%S")
    if account:
        filt.acctCode = account

    fills = ib.reqExecutions(filt)
    if not fills:
        return 0, f"No IBKR executions found for {target_date}."
    try:
        ib.sleep(3.0)
        refreshed = {
            str(getattr(getattr(fill, "execution", None), "execId", "") or ""): fill
            for fill in (ib.fills() or [])
        }
        fills = [
            refreshed.get(str(getattr(getattr(fill, "execution", None), "execId", "") or ""), fill)
            for fill in fills
        ]
    except Exception:
        pass

    grouped: dict[tuple, dict] = {}
    for fill in fills:
        contract = getattr(fill, "contract", None)
        execution = getattr(fill, "execution", None)
        if contract is None or execution is None:
            continue
        if account and getattr(execution, "acctNumber", None) and getattr(execution, "acctNumber", None) != account:
            continue

        symbol = str(getattr(contract, "symbol", "") or "").upper()
        sec_type = str(getattr(contract, "secType", "") or "").upper()
        side = str(getattr(execution, "side", "") or "").upper()
        if not symbol or side not in {"BOT", "BUY", "SLD", "SELL"}:
            continue

        con_id = getattr(contract, "conId", None)
        try:
            multiplier = float(getattr(contract, "multiplier", None) or (100 if sec_type in {"OPT", "FOP"} else 1))
        except Exception:
            multiplier = 100.0 if sec_type in {"OPT", "FOP"} else 1.0
        expiry = str(getattr(contract, "lastTradeDateOrContractMonth", "") or "")
        strike = getattr(contract, "strike", "")
        right = str(getattr(contract, "right", "") or "").upper()
        signal = "CALL" if right.startswith("C") else "PUT" if right.startswith("P") else ""
        local_symbol = str(getattr(contract, "localSymbol", "") or "")
        option_label = local_symbol or " ".join(x for x in [symbol, expiry, str(strike), signal] if x)
        event = "ENTRY" if side in {"BOT", "BUY"} else "EXIT"
        group_side = "BUY" if event == "ENTRY" else "SELL"
        key = (con_id or option_label, group_side)

        shares = abs(float(getattr(execution, "shares", 0) or 0))
        price = float(getattr(execution, "price", 0) or 0)
        exec_time = getattr(execution, "time", None) or datetime.now(EASTERN)
        if hasattr(exec_time, "astimezone"):
            exec_time = exec_time.astimezone(EASTERN)
        try:
            if exec_time.date() != target_date:
                continue
        except Exception:
            continue

        row = grouped.setdefault(key, {
            "timestamp": exec_time,
            "event": event,
            "source": "IBKR_EXECUTION",
            "external_id": f"IBKR_EXEC-{target_date}-{key[0]}-{group_side}",
            "symbol": symbol,
            "signal": signal,
            "option": option_label,
            "expiry": expiry,
            "strike": strike,
            "con_id": con_id,
            "sec_type": sec_type,
            "multiplier": multiplier,
            "quantity": 0.0,
            "value": 0.0,
            "exec_ids": [],
            "broker_order_ids": [],
            "broker_perm_ids": [],
            "broker_client_ids": [],
            "broker_order_refs": [],
            "broker_liquidation_flags": [],
            "commission": 0.0,
            "broker_realized_pnl": None,
            "broker_realized_quantity": 0.0,
        })
        row["quantity"] += shares
        row["value"] += shares * price
        row["exec_ids"].append(str(getattr(execution, "execId", "")))
        commission_report = getattr(fill, "commissionReport", None)
        commission = _number_or_none(getattr(commission_report, "commission", None))
        broker_realized = _number_or_none(getattr(commission_report, "realizedPNL", None))
        report_exec_id = str(getattr(commission_report, "execId", "") or "")
        report_matches = bool(report_exec_id) and report_exec_id == str(getattr(execution, "execId", "") or "")
        if commission is not None and abs(commission) < 1e100 and report_matches:
            row["commission"] -= abs(float(commission))
            if event == "EXIT" and broker_realized is not None and abs(broker_realized) < 1e100:
                current_realized = row.get("broker_realized_pnl")
                row["broker_realized_pnl"] = float(current_realized or 0.0) + float(broker_realized)
                row["broker_realized_quantity"] += shares
        for source_attr, target_key in [
            ("orderId", "broker_order_ids"),
            ("permId", "broker_perm_ids"),
            ("clientId", "broker_client_ids"),
            ("orderRef", "broker_order_refs"),
            ("liquidation", "broker_liquidation_flags"),
        ]:
            value = getattr(execution, source_attr, None)
            if value is None or value == "":
                continue
            value = str(value)
            if value not in row[target_key]:
                row[target_key].append(value)
        if exec_time and exec_time < row["timestamp"]:
            row["timestamp"] = exec_time

    if not grouped:
        return 0, f"No stock/option executions found for {target_date}."

    path = _Path(TRADE_LOG_FILE)
    existing = pd.read_csv(path) if path.exists() else pd.DataFrame()
    if not existing.empty:
        existing = existing.astype("object")

    def _contract_lookup_key(value) -> str:
        numeric = _number_or_none(value)
        if numeric is not None and numeric != 0:
            return str(int(numeric))
        return str(value or "").strip().upper()

    def _existing_entry_prices_by_contract(existing_df: pd.DataFrame) -> dict[str, tuple[float, float]]:
        if existing_df.empty or "event" not in existing_df.columns:
            return {}
        entries = existing_df[existing_df["event"].fillna("").astype(str).str.upper().eq("ENTRY")].copy()
        if entries.empty or "entry_price" not in entries.columns:
            return {}
        entries["_entry_price_num"] = pd.to_numeric(entries["entry_price"], errors="coerce")
        entries = entries[entries["_entry_price_num"].notna() & (entries["_entry_price_num"] > 0)].copy()
        if entries.empty:
            return {}
        if "source" in entries.columns:
            source_rank = entries["source"].fillna("").astype(str).str.upper().map({"IBKR_EXECUTION": 0, "IBKR_FLEX": 1}).fillna(2)
            entries["_source_rank"] = source_rank
        else:
            entries["_source_rank"] = 2
        if "timestamp" in entries.columns:
            entries["_entry_ts"] = _parse_timestamps_utc(entries["timestamp"])
        else:
            entries["_entry_ts"] = pd.NaT
        entries["_contract_key"] = entries.apply(lambda row: _contract_lookup_key(row.get("con_id") or row.get("option")), axis=1)
        if "filled_quantity" in entries.columns:
            qty_source = entries["filled_quantity"].combine_first(entries.get("quantity"))
        elif "quantity" in entries.columns:
            qty_source = entries["quantity"]
        else:
            qty_source = pd.Series([0] * len(entries), index=entries.index)
        entries["_qty_num"] = pd.to_numeric(qty_source, errors="coerce").fillna(0).abs()
        entries["_multiplier_num"] = pd.to_numeric(entries.get("multiplier", pd.Series([None] * len(entries), index=entries.index)), errors="coerce")

        out: dict[str, tuple[float, float]] = {}
        for contract_key, contract_entries in entries.groupby("_contract_key", sort=False):
            if not contract_key:
                continue
            source_choices = []
            for source_rank, source_entries in contract_entries.groupby("_source_rank", sort=True):
                source_choices.append((float(source_entries["_qty_num"].sum()), float(source_rank), source_entries))
            _, _, ranked_entries = sorted(source_choices, key=lambda choice: (-choice[0], choice[1]))[0]
            ranked_entries = ranked_entries.copy()
            if "_entry_ts" in ranked_entries.columns:
                ranked_entries = ranked_entries.sort_values("_entry_ts")
            qty = ranked_entries["_qty_num"]
            prices = ranked_entries["_entry_price_num"]
            valid = prices.notna()
            if valid.any() and qty[valid].sum() > 0:
                entry_price = float((prices[valid] * qty[valid]).sum() / qty[valid].sum())
            elif valid.any():
                entry_price = float(prices[valid].iloc[-1])
            else:
                continue
            multiplier = _number_or_none(ranked_entries["_multiplier_num"].dropna().iloc[-1] if ranked_entries["_multiplier_num"].notna().any() else None)
            if multiplier is None:
                sec_type = str(ranked_entries.get("sec_type", pd.Series(dtype=str)).dropna().astype(str).iloc[-1] if "sec_type" in ranked_entries.columns and ranked_entries["sec_type"].notna().any() else "").upper()
                multiplier = 100.0 if sec_type in {"OPT", "FOP"} else 1.0
            out[contract_key] = (entry_price, float(multiplier))
        return out

    existing_entry_price_by_contract = _existing_entry_prices_by_contract(existing)
    rows = []
    entry_price_by_contract = {}
    for key, item in grouped.items():
        net_complete = item["event"] == "EXIT" and item["broker_realized_quantity"] >= item["quantity"]
        avg_price = item["value"] / item["quantity"] if item["quantity"] else 0.0
        if item["event"] == "ENTRY":
            entry_price_by_contract[_contract_lookup_key(key[0])] = (avg_price, float(item.get("multiplier") or 1.0))
        rows.append(item | {
            "timestamp": item["timestamp"].isoformat() if hasattr(item["timestamp"], "isoformat") else str(item["timestamp"]),
            "quantity": int(item["quantity"]) if float(item["quantity"]).is_integer() else item["quantity"],
            "filled_quantity": int(item["quantity"]) if float(item["quantity"]).is_integer() else item["quantity"],
            "entry_price": round(avg_price, 4) if item["event"] == "ENTRY" else None,
            "exit_price": round(avg_price, 4) if item["event"] == "EXIT" else None,
            "limit_price": round(avg_price, 4) if item["event"] == "ENTRY" else None,
            "realized_pnl": round(float(item["broker_realized_pnl"]), 2) if item["event"] == "EXIT" and item.get("broker_realized_pnl") is not None else 0.0,
            "commission": round(float(item.get("commission") or 0.0), 6),
            "status": "Filled",
            "broker_status": "Execution",
            "exec_ids": ",".join(item["exec_ids"]),
            "broker_order_ids": ",".join(item.get("broker_order_ids") or []),
            "broker_perm_ids": ",".join(item.get("broker_perm_ids") or []),
            "broker_client_ids": ",".join(item.get("broker_client_ids") or []),
            "broker_order_refs": ",".join(item.get("broker_order_refs") or []),
            "broker_liquidation_flags": ",".join(item.get("broker_liquidation_flags") or []),
            "exit_reason": "IBKR sell execution imported" if item["event"] == "EXIT" else None,
            "pnl_basis": "broker_net" if net_complete else "pending_broker" if item["event"] == "EXIT" else None,
        })

    for row in rows:
        if row["event"] != "EXIT":
            continue
        entry_price = entry_price_by_contract.get(_contract_lookup_key(row.get("con_id") or row.get("option")))
        if not entry_price:
            entry_price = existing_entry_price_by_contract.get(_contract_lookup_key(row.get("con_id") or row.get("option")))
        if entry_price:
            if isinstance(entry_price, tuple):
                entry_price, multiplier = entry_price
            else:
                multiplier = 100.0 if str(row.get("sec_type", "")).upper() in {"OPT", "FOP"} else 1.0
            row["entry_price"] = round(float(entry_price), 4)
            if row.get("broker_realized_pnl") is None:
                row["realized_pnl"] = round((float(row["exit_price"]) - float(entry_price)) * float(row["quantity"]) * float(multiplier), 2)

    existing_ids = set(existing.get("external_id", pd.Series(dtype=str)).dropna().astype(str).tolist()) if not existing.empty else set()
    existing_trade_keys = set()
    if not existing.empty:
        existing_ts = _parse_timestamps_utc(existing.get("timestamp", pd.Series(dtype=str))).dt.tz_convert(EASTERN)
        for pos, (_, old) in enumerate(existing.iterrows()):
            try:
                old_date = existing_ts.iloc[pos].date()
            except Exception:
                old_date = None
            old_event = str(old.get("event", "") or "").upper()
            old_contract = str(old.get("con_id", "") or old.get("option", "") or "")
            old_qty = _number_or_none(old.get("filled_quantity")) or _number_or_none(old.get("quantity")) or 0.0
            old_price = _number_or_none(old.get("entry_price")) if old_event == "ENTRY" else _number_or_none(old.get("exit_price"))
            existing_trade_keys.add((old_date, old_event, old_contract, round(float(old_qty), 4), round(float(old_price or 0.0), 4)))
    imported = 0
    new_rows = []

    for row in rows:
        if row["external_id"] in existing_ids:
            matching = existing.index[existing["external_id"].fillna("").astype(str).eq(str(row["external_id"]))]
            if len(matching):
                row_values = {k: v for k, v in row.items() if k not in {"value", "broker_realized_pnl", "broker_realized_quantity"} and v is not None}
                for column, value in row_values.items():
                    if column not in existing.columns:
                        existing[column] = None
                    existing.loc[matching, column] = value
                imported += 1
            continue
        row_contract = str(row.get("con_id", "") or row.get("option", "") or "")
        row_price = row.get("entry_price") if row["event"] == "ENTRY" else row.get("exit_price")
        trade_key = (
            target_date,
            str(row.get("event", "") or "").upper(),
            row_contract,
            round(float(row.get("filled_quantity") or row.get("quantity") or 0.0), 4),
            round(float(row_price or 0.0), 4),
        )
        if trade_key in existing_trade_keys:
            continue
        new_rows.append({k: v for k, v in row.items() if k not in {"value", "broker_realized_pnl", "broker_realized_quantity"}})
        imported += 1
        existing_ids.add(row["external_id"])
        existing_trade_keys.add(trade_key)

    combined = pd.concat([existing, pd.DataFrame(new_rows)], ignore_index=True, sort=False) if new_rows else existing
    if not combined.empty and "timestamp" in combined.columns:
        sort_ts = _parse_timestamps_utc(combined["timestamp"])
        combined = combined.assign(_sort_ts=sort_ts).sort_values("_sort_ts", na_position="last").drop(columns=["_sort_ts"])
    from modules.performance_metrics import deduplicate_broker_event_rows
    combined = deduplicate_broker_event_rows(combined)
    combined.to_csv(path, index=False)
    return imported, f"IBKR executions grouped={len(rows)} imported_or_updated={imported}"


def read_active_positions() -> list[dict]:
    if not os.path.exists(ACTIVE_POSITIONS_FILE):
        return []
    try:
        with open(ACTIVE_POSITIONS_FILE, "r") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def write_active_positions(positions: list[dict]):
    with open(ACTIVE_POSITIONS_FILE, "w") as f:
        json.dump(positions, f, indent=2, default=str)


def is_filled_order_status(status: str) -> bool:
    """Return True only when an entry order created a real broker position."""
    return str(status or "").strip().lower() in {"filled", "filled via ibkr sync", "partiallyfilled", "partially filled"}


def _number_or_none(value) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(str(value).replace(",", ""))
    except Exception:
        return None


def is_manual_order_metadata(value: dict | None) -> bool:
    """Identify positions or log rows originating from the manual-order tab."""
    value = value or {}
    mode = str(value.get("management_mode") or "").strip().lower()
    if mode == POSITION_MANAGEMENT_MONITOR_ONLY:
        return True
    sources = {
        str(value.get("source") or "").strip().lower(),
        str(value.get("entry_source") or "").strip().lower(),
    }
    if MANUAL_ORDER_SOURCE in sources:
        return True
    return (
        str(value.get("score") or "").strip().upper() == "MANUAL"
        and str(value.get("setup_quality") or "").strip().lower() == "manual order"
    )


def is_monitor_only_position(position: dict | None) -> bool:
    position = position or {}
    if position.get("software_control_enabled") is False:
        return True
    if is_manual_order_metadata(position):
        return True
    lookup = _trade_log_entry_lookup()
    history = [lookup[key] for key in _position_history_keys(position) if key in lookup]
    if any(is_manual_order_metadata(row) for row in history):
        return True
    # Unknown/external holdings are not permission to automate an exit.
    for row in [position] + history:
        if str(row.get("management_mode") or "").lower() == POSITION_MANAGEMENT_AUTOMATED:
            return False
        if str(row.get("entry_source") or row.get("source") or "").lower() in {"scanner", "opening_orb"}:
            return False
        score = _number_or_none(row.get("score"))
        if score is not None and math.isfinite(score):
            return False
    return True


def _position_history_keys(position: dict) -> list[str]:
    keys = []
    con_id = _number_or_none(position.get("con_id"))
    if con_id is not None and math.isfinite(con_id) and con_id > 0:
        keys.append(f"conid:{int(con_id)}")
    symbol = str(position.get("symbol") or "").upper()
    expiry = str(position.get("expiry") or "").removesuffix(".0")
    strike = _number_or_none(position.get("strike"))
    right = {"CALL": "C", "PUT": "P", "C": "C", "P": "P"}.get(str(position.get("signal") or "").upper())
    if symbol and expiry and strike is not None and math.isfinite(strike) and right:
        keys.append(f"opt:{symbol}:{expiry}:{strike:g}:{right}")
    if position.get("option"):
        keys.append(f"label:{position['option']}")
    return keys


def is_prior_session_position(position: dict, now_et: datetime | None = None) -> bool:
    """Prior New York session holdings are outside automated exit ownership."""
    now_et = now_et or datetime.now(EASTERN)
    raw = position.get("entry_time") or position.get("opened_at") or position.get("timestamp")
    if not raw:
        lookup = _trade_log_entry_lookup()
        for key in _position_history_keys(position):
            if key in lookup:
                row = lookup[key]
                raw = row.get("entry_time") or row.get("timestamp") or row.get("opened_at")
                if raw:
                    break
    try:
        opened = datetime.fromisoformat(str(raw))
        if opened.tzinfo is None:
            opened = opened.replace(tzinfo=EASTERN)
        return opened.astimezone(EASTERN).date() < now_et.astimezone(EASTERN).date()
    except (ValueError, TypeError):
        return False


def assert_position_exit_allowed(position: dict) -> None:
    if is_prior_session_position(position):
        raise ValueError("Prior-session position is monitor only; PulseTrade exits are prohibited")
    # Check both persisted provenance and live local records at the final order boundary.
    keys = set(_position_history_keys(position))
    manual = is_monitor_only_position(position)
    for existing in read_active_positions():
        if keys.intersection(_position_history_keys(existing)) and (is_monitor_only_position(existing) or is_prior_session_position(existing)):
            manual = True
    if manual:
        raise ValueError("Manual position is monitor only; PulseTrade exits are prohibited")


def disable_manual_position_exits(ib: IB, pos: dict) -> list[dict]:
    pos.update(management_mode=POSITION_MANAGEMENT_MONITOR_ONLY, software_control_enabled=False,
               current_stop_price=None, take_profit_price=None, breakeven_active=False,
               trailing_active=False, trailing_from_entry=False)
    events = []
    # Tracked IDs alone are insufficient: earlier code could adopt user-created orders.
    for trade in _open_sell_trades_for_position(ib, pos):
        order = trade.order
        if not str(getattr(order, "ocaGroup", "") or "").startswith("PulseProtect-"):
            continue
        if pos.get("account") and getattr(order, "account", None) != pos["account"]:
            continue
        try:
            ib.cancelOrder(order)
            events.append({"Symbol": pos.get("symbol"), "Action": "CANCEL_MANUAL_POSITION_PROTECTION",
                           "Order ID": _order_id(order)})
        except Exception as exc:
            events.append({"Symbol": pos.get("symbol"), "Action": "CANCEL_PROTECTION_FAILED", "Status": str(exc)})
    pos["protective_orders_status"] = (
        "Monitor only - broker cancellation requires verification" if events
        else "Monitor only - no PulseTrade exit orders"
    )
    return events


def _position_age_seconds(pos: dict, now_et: datetime) -> float | None:
    raw = pos.get("entry_time") or pos.get("timestamp") or pos.get("opened_at")
    if not raw:
        return None
    try:
        opened = datetime.fromisoformat(str(raw))
        if opened.tzinfo is None:
            opened = opened.replace(tzinfo=EASTERN)
        return max(0.0, (now_et - opened.astimezone(EASTERN)).total_seconds())
    except Exception:
        return None


def record_position_market_snapshot(
    pos: dict,
    market: dict,
    now_et: datetime,
) -> float | None:
    """Persist the latest option quote and derived open-position P/L fields."""
    checked_at = now_et.isoformat()
    pos["market_data_checked_at"] = checked_at

    current_price = _finite_number(market.get("Mid"))
    if current_price is None or current_price <= 0:
        pos["market_data_status"] = "Quote unavailable"
        pos["market_data_stale"] = True
        pos["premium_health"] = "Unavailable"
        pos["premium_health_detail"] = "IBKR did not return a current option quote."
        pos["premium_health_checked_at"] = checked_at
        return None

    pos["market_data_status"] = "Live"
    pos["market_data_stale"] = False
    pos["market_data_source"] = str(market.get("Quote Source") or "IBKR snapshot")
    pos["current_price"] = round(current_price, 2)

    quote_fields = {
        "Bid": ("current_bid", 2),
        "Ask": ("current_ask", 2),
        "Last": ("current_last", 2),
        "Delta": ("current_delta", 4),
        "Gamma": ("current_gamma", 6),
        "Theta": ("current_theta", 6),
        "Vega": ("current_vega", 6),
        "Implied Vol": ("current_implied_vol", 4),
    }
    for source_key, (target_key, precision) in quote_fields.items():
        value = _finite_number(market.get(source_key))
        if value is not None:
            pos[target_key] = round(value, precision)
        else:
            pos.pop(target_key, None)

    spread_fraction = _finite_number(market.get("Spread %"))
    if spread_fraction is not None:
        pos["current_spread_pct"] = round(spread_fraction * 100.0, 2)
    else:
        pos.pop("current_spread_pct", None)
    volume = _finite_number(market.get("Volume"))
    if volume is not None:
        pos["current_option_volume"] = int(volume)
    else:
        pos.pop("current_option_volume", None)

    entry_price = _finite_number(pos.get("entry_price"))
    quantity = _finite_number(pos.get("quantity"))
    if entry_price is not None and entry_price > 0 and quantity is not None and quantity > 0:
        pos["cost_basis"] = round(entry_price * quantity * 100.0, 2)
        pos["market_value"] = round(current_price * quantity * 100.0, 2)
        pos["unrealized_pnl"] = round((current_price - entry_price) * quantity * 100.0, 2)
        pos["unrealized_pct"] = round(((current_price - entry_price) / entry_price) * 100.0, 2)

    broker_market_value = _finite_number(market.get("Portfolio Market Value"))
    if broker_market_value is not None:
        pos["market_value"] = round(broker_market_value, 2)
    broker_unrealized = _finite_number(market.get("Portfolio Unrealized PnL"))
    if broker_unrealized is not None:
        pos["unrealized_pnl"] = round(broker_unrealized, 2)
        cost_basis = _finite_number(pos.get("cost_basis"))
        if cost_basis is not None and cost_basis > 0:
            pos["unrealized_pct"] = round((broker_unrealized / cost_basis) * 100.0, 2)

    return current_price


def evaluate_premium_health(
    ib: IB,
    pos: dict,
    current_price: float,
    now_et: datetime,
) -> list[dict]:
    """Update premium health fields and tighten the stop when premium behaves poorly."""
    events: list[dict] = []
    entry_price = _number_or_none(pos.get("entry_price"))
    if not entry_price or entry_price <= 0 or not current_price or current_price <= 0:
        pos["premium_health"] = "Unavailable"
        pos["premium_health_detail"] = "Missing option entry/current premium."
        return events

    age_seconds = _position_age_seconds(pos, now_et)
    premium_change_pct = ((float(current_price) - entry_price) / entry_price) * 100.0
    pos["premium_change_pct"] = round(premium_change_pct, 2)
    pos["premium_health_checked_at"] = now_et.isoformat()

    if age_seconds is not None:
        pos["age_seconds"] = int(age_seconds)
    if age_seconds is not None and age_seconds < PREMIUM_HEALTH_WARMUP_SECONDS:
        remaining = int(PREMIUM_HEALTH_WARMUP_SECONDS - age_seconds)
        pos["premium_health"] = "Warming up"
        pos["premium_health_detail"] = f"Waiting {remaining}s before judging premium behavior."
        return events

    entry_underlying = _number_or_none(pos.get("underlying_entry_price"))
    current_underlying = None
    directional_underlying_pct = None
    if entry_underlying and entry_underlying > 0:
        current_underlying = get_stock_snapshot_price(ib, str(pos.get("symbol") or ""))
        if current_underlying and current_underlying > 0:
            raw_underlying_pct = ((current_underlying - entry_underlying) / entry_underlying) * 100.0
            signal = str(pos.get("signal") or "").upper()
            directional_underlying_pct = raw_underlying_pct if signal == "CALL" else -raw_underlying_pct
            pos["underlying_current_price"] = round(float(current_underlying), 2)
            pos["underlying_move_with_position_pct"] = round(float(directional_underlying_pct), 2)

    if directional_underlying_pct is None:
        if premium_change_pct <= PREMIUM_HEALTH_WEAK_DROP_PCT:
            pos["premium_health"] = "Premium weak"
            pos["premium_health_detail"] = f"Premium {premium_change_pct:.1f}%; stock entry anchor unavailable."
        else:
            pos["premium_health"] = "Watching"
            pos["premium_health_detail"] = f"Premium {premium_change_pct:.1f}%; stock entry anchor unavailable."
        return events

    weak_premium = (
        premium_change_pct <= PREMIUM_HEALTH_WEAK_DROP_PCT
        and directional_underlying_pct >= PREMIUM_HEALTH_UNDERLYING_TOLERANCE_PCT
    )
    if weak_premium:
        old_stop = _number_or_none(pos.get("current_stop_price")) or entry_price * (1 - DEFAULT_STOP_LOSS_PCT / 100.0)
        tightened_stop = round(max(float(old_stop), float(current_price) * (1 - PREMIUM_HEALTH_TIGHTEN_STOP_BUFFER_PCT / 100.0)), 2)
        if tightened_stop > float(old_stop) + 0.009:
            pos["current_stop_price"] = tightened_stop
            pos["premium_health_stop_tightened_at"] = now_et.isoformat()
            pos["premium_health_stop_tightened_price"] = tightened_stop
            events.append({
                "Symbol": pos.get("symbol"),
                "Option": pos.get("option"),
                "Action": "PREMIUM_HEALTH_TIGHTEN_STOP",
                "Premium %": round(premium_change_pct, 1),
                "Stock With Trade %": round(directional_underlying_pct, 2),
                "Old Stop": round(float(old_stop), 2),
                "New Stop": tightened_stop,
            })
        pos["premium_health"] = "Weak - stop tightened"
        pos["premium_health_detail"] = (
            f"Premium {premium_change_pct:.1f}% while stock is {directional_underlying_pct:.2f}% with trade."
        )
        return events

    if premium_change_pct <= PREMIUM_HEALTH_WEAK_DROP_PCT:
        pos["premium_health"] = "Weak but stock against"
        pos["premium_health_detail"] = (
            f"Premium {premium_change_pct:.1f}%; stock is {directional_underlying_pct:.2f}% with trade."
        )
    else:
        pos["premium_health"] = "Healthy"
        pos["premium_health_detail"] = (
            f"Premium {premium_change_pct:.1f}%; stock is {directional_underlying_pct:.2f}% with trade."
        )
    return events


def _parse_timestamps_utc(values):
    try:
        return pd.to_datetime(values, errors="coerce", utc=True, format="mixed")
    except TypeError:
        return pd.to_datetime(values, errors="coerce", utc=True)


def _broker_position_contract_key(contract) -> str:
    con_id = getattr(contract, "conId", None)
    if con_id:
        return f"conid:{int(con_id)}"
    symbol = str(getattr(contract, "symbol", "") or "").upper()
    expiry = str(getattr(contract, "lastTradeDateOrContractMonth", "") or "")
    strike = str(getattr(contract, "strike", "") or "")
    right = str(getattr(contract, "right", "") or "").upper()
    return f"opt:{symbol}:{expiry}:{strike}:{right}"


def broker_open_option_positions(ib: IB, account: str | None = None) -> list[dict]:
    """Return non-zero option positions currently visible at IBKR."""
    positions = []
    from modules.pine_options import owned_contracts
    from pathlib import Path
    pine_ids=owned_contracts(Path(__file__).resolve().parent/'data'/'pine_stock_trades.sqlite',account)
    for broker_pos in ib.positions():
        if account and getattr(broker_pos, "account", None) != account:
            continue
        contract = getattr(broker_pos, "contract", None)
        if contract is None:
            continue
        if str(getattr(contract, "secType", "") or "").upper() != "OPT":
            continue
        if getattr(contract,'conId',None) in pine_ids:
            continue
        try:
            qty = float(getattr(broker_pos, "position", 0) or 0)
        except Exception:
            continue
        if qty == 0:
            continue
        right = str(getattr(contract, "right", "") or "").upper()
        positions.append({
            "key": _broker_position_contract_key(contract),
            "symbol": str(getattr(contract, "symbol", "") or "").upper(),
            "signal": "CALL" if right.startswith("C") else "PUT" if right.startswith("P") else "",
            "option": str(getattr(contract, "localSymbol", "") or ""),
            "expiry": str(getattr(contract, "lastTradeDateOrContractMonth", "") or ""),
            "strike": float(getattr(contract, "strike", 0) or 0),
            "con_id": getattr(contract, "conId", None),
            "quantity": int(abs(qty)) if float(abs(qty)).is_integer() else abs(qty),
            "avg_cost": float(getattr(broker_pos, "avgCost", 0) or 0),
            "account": getattr(broker_pos, "account", None),
        })
    return positions


def broker_open_option_symbols(ib: IB, account: str | None = None) -> set[str]:
    # Pine-owned contracts stay outside PMB exits, but their underlyings still
    # block a second strategy from accumulating the same option position.
    return {str(p.contract.symbol).upper() for p in ib.positions() if (not account or p.account==account)
        and getattr(p.contract,'secType','')=='OPT' and p.position!=0}


def _trade_log_entry_lookup() -> dict[str, dict]:
    if not os.path.exists(TRADE_LOG_FILE):
        return {}
    try:
        df = pd.read_csv(TRADE_LOG_FILE)
    except Exception:
        return {}
    if df.empty or "event" not in df.columns:
        return {}

    df = df[df["event"].fillna("").astype(str).str.upper() == "ENTRY"].copy()
    if df.empty:
        return {}
    if "timestamp" in df.columns:
        df["timestamp"] = _parse_timestamps_utc(df["timestamp"])
        df = df.sort_values("timestamp")

    lookup: dict[str, dict] = {}
    for _, row in df.iterrows():
        record = row.to_dict()
        for key in _position_history_keys(record):
            # Broker imports must never erase evidence of a manual entry.
            previous = lookup.get(key, {})
            if is_manual_order_metadata(previous) and not is_manual_order_metadata(record):
                continue
            lookup[key] = record
    return lookup


def sync_active_positions_from_broker(
    ib: IB,
    account: str | None = None,
    stop_loss_pct: float = DEFAULT_STOP_LOSS_PCT,
    take_profit_pct: float = DEFAULT_TAKE_PROFIT_PCT,
    trailing_stop_pct: float = 0.0,
    trailing_from_entry: bool = False,
    fixed_take_profit_enabled: bool = True,
    submit_protection: bool = False,
    exit_evaluation_mode: str = "snapshot",
) -> list[dict]:
    """Add missing local active-position records for filled IBKR option positions.

    This covers the case where the order callback said Inactive/Submitted locally
    but IBKR later reports a real execution/position.
    """
    broker_positions = broker_open_option_positions(ib, account=account)
    if not broker_positions:
        return []

    local_positions = read_active_positions()
    local_keys = set()
    for pos in local_positions:
        if pos.get("con_id"):
            try:
                local_keys.add(f"conid:{int(pos.get('con_id'))}")
            except Exception:
                pass
        option = str(pos.get("option", "") or "")
        if option:
            local_keys.add(f"label:{option}")

    entry_lookup = _trade_log_entry_lookup()
    added = []
    for broker_pos in broker_positions:
        key = broker_pos["key"]
        option = broker_pos.get("option") or " ".join(
            str(x) for x in [
                broker_pos.get("symbol"),
                broker_pos.get("expiry"),
                broker_pos.get("strike"),
                broker_pos.get("signal"),
            ] if x
        )
        if key in local_keys or f"label:{option}" in local_keys:
            continue

        broker_signal = broker_pos.get("signal") or ""
        right = "C" if broker_signal == "CALL" else "P" if broker_signal == "PUT" else ""
        contract_key = (
            f"opt:{str(broker_pos.get('symbol') or '').upper()}:{broker_pos.get('expiry')}:{float(broker_pos.get('strike') or 0):g}:{right}"
            if right else ""
        )
        log_row = entry_lookup.get(key) or entry_lookup.get(contract_key) or entry_lookup.get(f"label:{option}") or {}
        entry_price = _number_or_none(log_row.get("entry_price")) if log_row else None
        if entry_price is None:
            entry_price = _number_or_none(log_row.get("limit_price")) if log_row else None
        if entry_price is None:
            avg_cost = float(broker_pos.get("avg_cost") or 0)
            entry_price = avg_cost / 100.0 if avg_cost > 10 else avg_cost
        if not entry_price or entry_price <= 0:
            continue

        symbol = broker_pos.get("symbol") or str(log_row.get("symbol", "") or "").upper()
        signal = broker_pos.get("signal") or str(log_row.get("signal", "") or "").upper()
        monitor_only = not log_row or is_monitor_only_position(log_row)
        position_id = f"{symbol}-{broker_pos.get('expiry')}-{broker_pos.get('strike')}-{signal}-{datetime.now(EASTERN).strftime('%Y%m%d%H%M%S')}"
        initial_stop_pct = float(trailing_stop_pct) if trailing_from_entry and float(trailing_stop_pct or 0) > 0 else float(stop_loss_pct)
        position = {
            "id": position_id,
            "symbol": symbol,
            "signal": signal,
            "option": option,
            "expiry": broker_pos.get("expiry"),
            "strike": float(broker_pos.get("strike") or 0),
            "con_id": broker_pos.get("con_id"),
            "quantity": broker_pos.get("quantity"),
            "entry_price": round(float(entry_price), 2),
            "underlying_entry_price": _number_or_none(log_row.get("price")) if log_row is not None else None,
            "current_stop_price": None if monitor_only else round(float(entry_price) * (1 - initial_stop_pct / 100), 2),
            "take_profit_price": None if monitor_only else round(float(entry_price) * (1 + float(take_profit_pct) / 100), 2),
            "take_profit_pct": round(float(take_profit_pct), 4),
            "highest_price": round(float(entry_price), 2),
            "breakeven_active": False,
            "trailing_active": False if monitor_only else bool(trailing_from_entry),
            "trailing_from_entry": False if monitor_only else bool(trailing_from_entry),
            "entry_time": str(log_row.get("timestamp") or datetime.now(EASTERN).isoformat()),
            "entry_status": "Filled",
            "source": "IBKR_POSITION_SYNC",
            "entry_source": log_row.get("source") if log_row is not None else None,
            "management_mode": POSITION_MANAGEMENT_MONITOR_ONLY if monitor_only else POSITION_MANAGEMENT_AUTOMATED,
            "software_control_enabled": not monitor_only,
            "protective_orders_status": "Monitor only - no PulseTrade exit orders" if monitor_only else "Not checked",
        }
        configure_option_exit_mode(position, exit_evaluation_mode, stop_loss_pct)
        if submit_protection and not monitor_only:
            protection_events = ensure_protective_orders(
                ib,
                position,
                account=account,
                stop_loss_pct=stop_loss_pct,
                take_profit_pct=take_profit_pct,
                fixed_take_profit_enabled=fixed_take_profit_enabled,
            )
        else:
            protection_events = []
        local_positions.append(position)
        added.append({
            "Symbol": symbol,
            "Option": option,
            "Action": "ADDED",
            "Reason": (
                "Manual-order position restored for monitoring only"
                if monitor_only else "Open IBKR position missing from local active positions"
            ),
        })
        added.extend(protection_events)

    if added:
        write_active_positions(local_positions)
    return added


def get_today_loss_stats() -> tuple[int, float]:
    """Return same-day consecutive losses and realized P/L from the local trade log.

    Overnight positions closed today are intentionally excluded from the live
    daily risk lock so yesterday's entry cannot block today's new trading.
    """
    if not os.path.exists(TRADE_LOG_FILE):
        return 0, 0.0
    try:
        df = _option_risk_rows(pd.read_csv(TRADE_LOG_FILE))
        if df.empty or "timestamp" not in df.columns or "event" not in df.columns:
            return 0, 0.0
        df["timestamp"] = _parse_timestamps_utc(df["timestamp"])
        today = datetime.now(EASTERN).date()
        df["_event"] = df["event"].fillna("").astype(str).str.upper()
        df["_local_date"] = df["timestamp"].dt.tz_convert(EASTERN).dt.date
        df["_realized_pnl"] = pd.to_numeric(df.get("realized_pnl", 0), errors="coerce").fillna(0.0)

        def _trade_key(row: pd.Series) -> str:
            con_id = _number_or_none(row.get("con_id"))
            if con_id is not None:
                return f"conid:{int(con_id)}"
            expiry = str(row.get("expiry") or "").strip()
            strike = _number_or_none(row.get("strike"))
            symbol = str(row.get("symbol") or "").strip().upper()
            signal = str(row.get("signal") or row.get("type") or "").strip().upper()
            if symbol and expiry and strike is not None and signal:
                return f"opt:{symbol}:{expiry}:{float(strike):g}:{signal}"
            return "label:" + re.sub(r"\s+", " ", str(row.get("option") or "").strip().upper())

        df["_trade_key"] = df.apply(_trade_key, axis=1)
        entries = df[df["_event"] == "ENTRY"].sort_values("timestamp")
        exits = df[(df["_event"] == "EXIT") & (df["_local_date"] == today)].sort_values("timestamp").copy()
        if exits.empty:
            return 0, 0.0

        same_day_exit_indexes = []
        for exit_index, exit_row in exits.iterrows():
            matching_entries = entries[
                (entries["_trade_key"] == exit_row["_trade_key"])
                & (entries["timestamp"] <= exit_row["timestamp"])
            ]
            if matching_entries.empty:
                same_day_exit_indexes.append(exit_index)
                continue
            entry_date = matching_entries.iloc[-1]["_local_date"]
            if entry_date == today:
                same_day_exit_indexes.append(exit_index)

        exits = exits.loc[same_day_exit_indexes].copy()
        if exits.empty:
            return 0, 0.0

        realized = float(exits["_realized_pnl"].sum())
        consecutive_losses = 0
        for pnl in reversed(exits["_realized_pnl"].tolist()):
            if pnl < 0:
                consecutive_losses += 1
            else:
                break
        return consecutive_losses, realized
    except Exception:
        return 0, 0.0


def reconstruct_option_contract(pos: dict):
    right = "C" if pos.get("signal") == "CALL" else "P"
    contract = Option(
        pos["symbol"],
        str(pos["expiry"]),
        float(pos["strike"]),
        right,
        "SMART",
        currency="USD",
        multiplier="100",
    )
    if pos.get("con_id"):
        contract.conId = int(pos["con_id"])
    return contract


def _trade_is_active(trade) -> bool:
    status = str(getattr(getattr(trade, "orderStatus", None), "status", "") or "").lower()
    return status not in {"filled", "cancelled", "canceled", "apicancelled", "inactive"}


def _order_id(order) -> int | None:
    try:
        value = int(getattr(order, "orderId", 0) or 0)
        return value if value > 0 else None
    except Exception:
        return None


def _coerce_order_id(value) -> int | None:
    try:
        value = int(float(value or 0))
        return value if value > 0 else None
    except Exception:
        return None


def _order_chunks(quantity: int, max_chunk: int = MAX_OPTION_ORDER_CHUNK_QTY) -> list[int]:
    quantity = int(abs(quantity or 0))
    if quantity <= 0:
        return []
    max_chunk = max(1, int(max_chunk or 1))
    return [min(max_chunk, quantity - offset) for offset in range(0, quantity, max_chunk)]


def _coerce_order_ids(value) -> list[int]:
    if isinstance(value, (list, tuple, set)):
        values = value
    elif isinstance(value, str) and "," in value:
        values = value.split(",")
    else:
        values = [value]
    ids = []
    for item in values:
        order_id = _coerce_order_id(item)
        if order_id:
            ids.append(order_id)
    return ids


def _open_sell_trades_for_position(ib: IB, pos: dict) -> list:
    try:
        ib.reqAllOpenOrders()
        ib.sleep(0.2)
    except Exception:
        try:
            ib.reqOpenOrders()
            ib.sleep(0.2)
        except Exception:
            pass

    con_id = pos.get("con_id")
    matches = []
    for trade in ib.openTrades() or []:
        if not _trade_is_active(trade):
            continue
        order = getattr(trade, "order", None)
        contract = getattr(trade, "contract", None)
        if str(getattr(order, "action", "") or "").upper() != "SELL":
            continue
        try:
            same_contract = bool(con_id and int(float(getattr(contract, "conId", 0) or 0)) == int(float(con_id)))
        except Exception:
            same_contract = False
        if same_contract or _position_matches_broker_position(pos, trade):
            matches.append(trade)
    return matches


def configure_option_exit_mode(pos: dict, mode: str, stop_loss_pct: float) -> None:
    if is_monitor_only_position(pos):
        return
    if mode == CANDLE_CLOSE_MODE and pos.get("exit_evaluation_mode") != mode:
        emergency = round(float(pos["entry_price"]) * (1 - float(stop_loss_pct) / 100), 2)
        pos.update(emergency_stop_price=emergency, current_stop_price=emergency,
                   highest_price=float(pos["entry_price"]), breakeven_active=False,
                   trailing_active=False, trailing_from_entry=False)
        pos.pop("last_exit_candle_at", None)
        pos.pop("option_candle_checked_through", None)
    pos["exit_evaluation_mode"] = mode


def ensure_protective_orders(ib: IB, pos: dict, account: str | None = None,
                             stop_loss_pct: float = DEFAULT_STOP_LOSS_PCT,
                             take_profit_pct: float = DEFAULT_TAKE_PROFIT_PCT,
                             fixed_take_profit_enabled: bool = True) -> list[dict]:
    if is_prior_session_position(pos):
        return [{"Symbol": pos.get("symbol"), "Action": "PRIOR_SESSION_MONITOR_ONLY",
                 "Reason": "Prior-session holding; existing broker orders left unchanged"}]
    if pos.get("exit_evaluation_mode") != CANDLE_CLOSE_MODE or is_monitor_only_position(pos):
        return _ensure_protective_orders(ib, pos, account, stop_loss_pct, take_profit_pct,
                                         fixed_take_profit_enabled)
    # Virtual profit protection must never become an intrabar broker stop.
    protection = dict(pos)
    protection["current_stop_price"] = pos["emergency_stop_price"]
    protection["trailing_active"] = True
    events = _ensure_protective_orders(ib, protection, account, stop_loss_pct,
                                      take_profit_pct, False)
    for key, value in protection.items():
        if key not in {"current_stop_price", "highest_price", "trailing_active", "take_profit_price"}:
            pos[key] = value
    pos["emergency_stop_price"] = protection["current_stop_price"]
    return events


def _ensure_protective_orders(
    ib: IB,
    pos: dict,
    account: str | None = None,
    stop_loss_pct: float = DEFAULT_STOP_LOSS_PCT,
    take_profit_pct: float = DEFAULT_TAKE_PROFIT_PCT,
    fixed_take_profit_enabled: bool = True,
) -> list[dict]:
    """Create missing broker-side fixed SL/TP OCA orders for an open option position."""
    if is_prior_session_position(pos):
        return []
    if is_monitor_only_position(pos):
        if account:
            pos["account"] = account
        return disable_manual_position_exits(ib, pos)

    qty = int(abs(float(pos.get("quantity", 0) or 0)))
    entry_price = float(pos.get("entry_price", 0) or 0)
    if qty <= 0 or entry_price <= 0:
        return []

    contract = reconstruct_option_contract(pos)
    try:
        qualified = ib.qualifyContracts(contract)
        if qualified:
            contract = qualified[0]
            pos["con_id"] = getattr(contract, "conId", pos.get("con_id"))
    except Exception:
        pass

    stop_price = round(max(0.01, float(pos.get("current_stop_price") or entry_price * (1 - float(stop_loss_pct) / 100))), 2)
    take_profit_price = round(max(0.01, float(pos.get("take_profit_price") or entry_price * (1 + float(take_profit_pct) / 100))), 2)
    pos["current_stop_price"] = stop_price
    pos["take_profit_price"] = take_profit_price

    open_sell_trades = _open_sell_trades_for_position(ib, pos)
    chunks = _order_chunks(qty)
    want_take_profit = bool(fixed_take_profit_enabled) and not bool(pos.get("trailing_active", False))
    price_tolerance = 0.009

    def _tracked_price(kind: str, order_id: int | None) -> float | None:
        if order_id:
            price_map = pos.get(f"ibkr_{kind}_order_prices_by_id")
            if isinstance(price_map, dict):
                value = _number_or_none(price_map.get(str(order_id)))
                if value is not None:
                    return float(value)
        value = _number_or_none(pos.get(f"ibkr_{kind}_order_price"))
        return float(value) if value is not None else None

    def _remember_protective_price(kind: str, order_id: int | None, price: float) -> None:
        rounded_price = round(float(price), 2)
        pos[f"ibkr_{kind}_order_price"] = rounded_price
        if order_id:
            price_map = pos.get(f"ibkr_{kind}_order_prices_by_id")
            if not isinstance(price_map, dict):
                price_map = {}
            price_map[str(order_id)] = rounded_price
            pos[f"ibkr_{kind}_order_prices_by_id"] = price_map

    def _tracked_protective_order_ids(kind: str) -> list[int]:
        ids = []
        ids.append(_coerce_order_id(pos.get(f"ibkr_{kind}_order_id")))
        ids.extend(_coerce_order_ids(pos.get(f"ibkr_{kind}_order_ids")))
        price_map = pos.get(f"ibkr_{kind}_order_prices_by_id")
        if isinstance(price_map, dict):
            ids.extend(_coerce_order_id(order_id) for order_id in price_map.keys())
        return sorted({order_id for order_id in ids if order_id})

    def _manual_cancel_is_active(kind: str) -> bool:
        return bool(pos.get(f"ibkr_{kind}_manual_cancelled") or pos.get(f"ibkr_{kind}_manual_override"))

    def _remember_manual_cancel(kind: str) -> None:
        label = "stop" if kind == "stop" else "take profit"
        pos[f"ibkr_{kind}_manual_override"] = True
        pos[f"ibkr_{kind}_manual_cancelled"] = True
        pos["protective_orders_status"] = f"Manual broker {label} cancel preserved"

    def _broker_price_is_manual_override(kind: str, order_id: int | None, broker_price: float, desired_price: float, position_price_key: str) -> bool:
        manual_key = f"ibkr_{kind}_manual_override"
        broker_price = round(float(broker_price), 2)
        desired_price = round(float(desired_price), 2)
        tracked_price = _tracked_price(kind, order_id)
        if bool(pos.get(manual_key, False)):
            pos[position_price_key] = broker_price
            _remember_protective_price(kind, order_id, broker_price)
            pos["protective_orders_status"] = "Manual broker SL/TP preserved"
            return True
        if tracked_price is None:
            _remember_protective_price(kind, order_id, broker_price)
            if abs(broker_price - desired_price) > price_tolerance:
                pos[manual_key] = True
                pos[position_price_key] = broker_price
                pos["protective_orders_status"] = "Manual broker SL/TP preserved"
                return True
            return False
        if abs(broker_price - float(tracked_price)) > price_tolerance:
            pos[manual_key] = True
            pos[position_price_key] = broker_price
            _remember_protective_price(kind, order_id, broker_price)
            pos["protective_orders_status"] = "Manual broker SL/TP preserved"
            return True
        return False

    if len(chunks) > 1:
        existing_stop_ids = []
        existing_take_profit_ids = []
        for trade in open_sell_trades:
            order = getattr(trade, "order", None)
            order_type = str(getattr(order, "orderType", "") or "").upper()
            if "STP" in order_type:
                existing_stop_ids.append(_order_id(order))
            elif order_type == "LMT":
                existing_take_profit_ids.append(_order_id(order))
        existing_stop_ids = [order_id for order_id in existing_stop_ids if order_id]
        existing_take_profit_ids = [order_id for order_id in existing_take_profit_ids if order_id]
        tracked_stop_ids = _tracked_protective_order_ids("stop")
        tracked_take_profit_ids = _tracked_protective_order_ids("take_profit")
        stop_manually_cancelled = (
            (bool(tracked_stop_ids) and not existing_stop_ids)
            or (_manual_cancel_is_active("stop") and not existing_stop_ids)
        )
        take_profit_manually_cancelled = (
            want_take_profit
            and (
                (bool(tracked_take_profit_ids) and not existing_take_profit_ids)
                or (_manual_cancel_is_active("take_profit") and not existing_take_profit_ids)
            )
        )
        if stop_manually_cancelled:
            _remember_manual_cancel("stop")
        if take_profit_manually_cancelled:
            _remember_manual_cancel("take_profit")
        if existing_stop_ids and (existing_take_profit_ids or not want_take_profit):
            pos["ibkr_stop_order_ids"] = existing_stop_ids
            pos["ibkr_take_profit_order_ids"] = existing_take_profit_ids
            pos["ibkr_stop_manual_cancelled"] = False
            if existing_take_profit_ids:
                pos["ibkr_take_profit_manual_cancelled"] = False
            events = []
            for trade in open_sell_trades:
                order = getattr(trade, "order", None)
                order_type = str(getattr(order, "orderType", "") or "").upper()
                if "STP" not in order_type:
                    continue
                order_id = _order_id(order)
                old_stop = float(getattr(order, "auxPrice", 0) or 0)
                manual = _broker_price_is_manual_override("stop", order_id, old_stop, stop_price, "current_stop_price")
                if not manual and pos.get("exit_evaluation_mode") == CANDLE_CLOSE_MODE and abs(old_stop - stop_price) > price_tolerance:
                    order.auxPrice = stop_price
                    ib.placeOrder(contract, order)
                    ib.sleep(0.2)
                    _remember_protective_price("stop", order_id, stop_price)
                    events.append({"Symbol": pos.get("symbol"), "Action": "UPDATE_EMERGENCY_STOP", "Stop": stop_price})
            if want_take_profit:
                for trade in open_sell_trades:
                    order = getattr(trade, "order", None)
                    order_type = str(getattr(order, "orderType", "") or "").upper()
                    if order_type != "LMT":
                        continue
                    order_id = _order_id(order)
                    old_target = float(getattr(order, "lmtPrice", 0) or 0)
                    if _broker_price_is_manual_override("take_profit", order_id, old_target, take_profit_price, "take_profit_price"):
                        continue
                    if abs(old_target - take_profit_price) <= price_tolerance:
                        continue
                    order.lmtPrice = take_profit_price
                    if account:
                        order.account = account
                    ib.placeOrder(contract, order)
                    ib.sleep(0.2)
                    _remember_protective_price("take_profit", order_id, take_profit_price)
                    pos["ibkr_take_profit_manual_override"] = False
                    pos["ibkr_take_profit_manual_cancelled"] = False
                    events.append({
                        "Symbol": pos.get("symbol"),
                        "Option": pos.get("option"),
                        "Action": "UPDATE_TP",
                        "Old TP": round(old_target, 2),
                        "TP": take_profit_price,
                        "Order ID": order_id,
                    })
            elif pos.get("exit_evaluation_mode") == CANDLE_CLOSE_MODE:
                # Remove old bot profit targets when migrating chunked positions.
                # Explicit manual broker changes remain authoritative.
                remaining_targets = []
                for trade in open_sell_trades:
                    order = getattr(trade, "order", None)
                    if str(getattr(order, "orderType", "")).upper() != "LMT":
                        continue
                    order_id = _order_id(order)
                    old_target = float(getattr(order, "lmtPrice", 0) or 0)
                    if _broker_price_is_manual_override("take_profit", order_id, old_target, take_profit_price, "take_profit_price"):
                        remaining_targets.append(order_id)
                        continue
                    ib.cancelOrder(order)
                    ib.sleep(0.2)
                    events.append({"Symbol": pos.get("symbol"), "Action": "CANCEL_TP_FOR_CANDLE_CLOSE", "Order ID": order_id})
                pos["ibkr_take_profit_order_ids"] = remaining_targets
            if events:
                pos["protective_orders_status"] = "Updated"
                return events
            if not (pos.get("ibkr_stop_manual_override") or pos.get("ibkr_take_profit_manual_override")):
                pos["protective_orders_status"] = "Already protected"
            return []
        if stop_manually_cancelled or take_profit_manually_cancelled:
            return []

        events = []
        stop_ids = []
        take_profit_ids = []
        base_group = str(pos.get("ibkr_oca_group") or f"PulseProtect-{pos.get('id') or pos.get('con_id')}-{int(time.time())}")
        pos["ibkr_oca_group"] = base_group
        for idx, chunk_qty in enumerate(chunks, start=1):
            oca_group = f"{base_group}-{idx}"
            stop_order = StopOrder("SELL", chunk_qty, stop_price)
            stop_order.ocaGroup = oca_group
            stop_order.ocaType = 1
            stop_order.tif = "DAY"
            if account:
                stop_order.account = account
            stop_trade = ib.placeOrder(contract, stop_order)
            ib.sleep(0.2)
            stop_id = _order_id(getattr(stop_trade, "order", None))
            stop_ids.append(stop_id)
            _remember_protective_price("stop", stop_id, stop_price)
            pos["ibkr_stop_manual_override"] = False
            pos["ibkr_stop_manual_cancelled"] = False
            events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "PROTECT_STOP", "Stop": stop_price, "Qty": chunk_qty})

            if want_take_profit:
                target_order = LimitOrder("SELL", chunk_qty, take_profit_price)
                target_order.ocaGroup = oca_group
                target_order.ocaType = 1
                target_order.tif = "DAY"
                if account:
                    target_order.account = account
                target_trade = ib.placeOrder(contract, target_order)
                ib.sleep(0.2)
                take_profit_id = _order_id(getattr(target_trade, "order", None))
                take_profit_ids.append(take_profit_id)
                _remember_protective_price("take_profit", take_profit_id, take_profit_price)
                pos["ibkr_take_profit_manual_override"] = False
                pos["ibkr_take_profit_manual_cancelled"] = False
                events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "PROTECT_TP", "TP": take_profit_price, "Qty": chunk_qty})

        pos["ibkr_stop_order_ids"] = [order_id for order_id in stop_ids if order_id]
        pos["ibkr_take_profit_order_ids"] = [order_id for order_id in take_profit_ids if order_id]
        pos["protective_orders_status"] = "Submitted" if events else "Already protected"
        return events

    existing_order_ids = {_order_id(getattr(trade, "order", None)) for trade in open_sell_trades}
    existing_order_ids.discard(None)

    stop_order_id = _coerce_order_id(pos.get("ibkr_stop_order_id"))
    take_profit_order_id = _coerce_order_id(pos.get("ibkr_take_profit_order_id"))
    has_stop = bool(stop_order_id and stop_order_id in existing_order_ids)
    has_take_profit = bool(take_profit_order_id and take_profit_order_id in existing_order_ids)
    stop_trade = None
    take_profit_trade = None

    for trade in open_sell_trades:
        order = getattr(trade, "order", None)
        order_type = str(getattr(order, "orderType", "") or "").upper()
        if "STP" in order_type and not has_stop:
            pos["ibkr_stop_order_id"] = _order_id(order)
            pos["ibkr_stop_manual_cancelled"] = False
            has_stop = True
            stop_trade = trade
        elif order_type == "LMT" and not has_take_profit:
            pos["ibkr_take_profit_order_id"] = _order_id(order)
            pos["ibkr_take_profit_manual_cancelled"] = False
            has_take_profit = True
            take_profit_trade = trade
        elif "STP" in order_type and _order_id(order) == stop_order_id:
            stop_trade = trade
        elif order_type == "LMT" and _order_id(order) == take_profit_order_id:
            take_profit_trade = trade

    tracked_stop_ids = _tracked_protective_order_ids("stop")
    tracked_take_profit_ids = _tracked_protective_order_ids("take_profit")
    if not has_stop and (tracked_stop_ids or _manual_cancel_is_active("stop")):
        _remember_manual_cancel("stop")
        has_stop = True
    if want_take_profit and not has_take_profit and (tracked_take_profit_ids or _manual_cancel_is_active("take_profit")):
        _remember_manual_cancel("take_profit")
        has_take_profit = True

    events = []
    oca_group = str(pos.get("ibkr_oca_group") or f"PulseProtect-{pos.get('id') or pos.get('con_id')}-{int(time.time())}")
    pos["ibkr_oca_group"] = oca_group

    if not want_take_profit:
        preserved_manual_take_profit = False
        for trade in open_sell_trades:
            order = getattr(trade, "order", None)
            order_type = str(getattr(order, "orderType", "") or "").upper()
            order_id = _order_id(order)
            if order_type != "LMT":
                continue
            if take_profit_order_id and order_id != take_profit_order_id:
                continue
            old_target = float(getattr(order, "lmtPrice", 0) or 0)
            if _broker_price_is_manual_override("take_profit", order_id, old_target, take_profit_price, "take_profit_price"):
                has_take_profit = True
                preserved_manual_take_profit = True
                continue
            try:
                ib.cancelOrder(order)
                ib.sleep(0.2)
                events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "CANCEL_TP_FOR_TRAIL", "Order ID": order_id})
            except Exception as exc:
                events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "CANCEL_TP_FAILED", "Status": str(exc)})
        if not preserved_manual_take_profit:
            pos["ibkr_take_profit_order_id"] = None
        has_take_profit = True

    if not has_stop:
        stop_order = StopOrder("SELL", qty, stop_price)
        stop_order.ocaGroup = oca_group
        stop_order.ocaType = 1
        stop_order.tif = "DAY"
        if account:
            stop_order.account = account
        trade = ib.placeOrder(contract, stop_order)
        ib.sleep(0.2)
        pos["ibkr_stop_order_id"] = _order_id(getattr(trade, "order", None))
        _remember_protective_price("stop", pos.get("ibkr_stop_order_id"), stop_price)
        pos["ibkr_stop_manual_override"] = False
        pos["ibkr_stop_manual_cancelled"] = False
        events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "PROTECT_STOP", "Stop": stop_price})
    elif stop_trade is not None:
        stop_order = getattr(stop_trade, "order", None)
        stop_order_id = _order_id(stop_order)
        old_stop = float(getattr(stop_order, "auxPrice", 0) or 0)
        if _broker_price_is_manual_override("stop", stop_order_id, old_stop, stop_price, "current_stop_price"):
            pass
        elif stop_price > old_stop + price_tolerance or (pos.get("exit_evaluation_mode") == CANDLE_CLOSE_MODE and abs(stop_price - old_stop) > price_tolerance):
            stop_order.auxPrice = stop_price
            if account:
                stop_order.account = account
            ib.placeOrder(contract, stop_order)
            ib.sleep(0.2)
            _remember_protective_price("stop", stop_order_id, stop_price)
            pos["ibkr_stop_manual_override"] = False
            pos["ibkr_stop_manual_cancelled"] = False
            events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "UPDATE_STOP", "Stop": stop_price})

    if want_take_profit and not has_take_profit:
        target_order = LimitOrder("SELL", qty, take_profit_price)
        target_order.ocaGroup = oca_group
        target_order.ocaType = 1
        target_order.tif = "DAY"
        if account:
            target_order.account = account
        trade = ib.placeOrder(contract, target_order)
        ib.sleep(0.2)
        pos["ibkr_take_profit_order_id"] = _order_id(getattr(trade, "order", None))
        _remember_protective_price("take_profit", pos.get("ibkr_take_profit_order_id"), take_profit_price)
        pos["ibkr_take_profit_manual_override"] = False
        pos["ibkr_take_profit_manual_cancelled"] = False
        events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "PROTECT_TP", "TP": take_profit_price})
    elif want_take_profit and take_profit_trade is not None:
        target_order = getattr(take_profit_trade, "order", None)
        take_profit_order_id = _order_id(target_order)
        old_target = float(getattr(target_order, "lmtPrice", 0) or 0)
        if _broker_price_is_manual_override("take_profit", take_profit_order_id, old_target, take_profit_price, "take_profit_price"):
            pass
        elif abs(old_target - take_profit_price) > price_tolerance:
            target_order.lmtPrice = take_profit_price
            if account:
                target_order.account = account
            ib.placeOrder(contract, target_order)
            ib.sleep(0.2)
            _remember_protective_price("take_profit", take_profit_order_id, take_profit_price)
            pos["ibkr_take_profit_manual_override"] = False
            pos["ibkr_take_profit_manual_cancelled"] = False
            events.append({
                "Symbol": pos.get("symbol"),
                "Option": pos.get("option"),
                "Action": "UPDATE_TP",
                "Old TP": round(old_target, 2),
                "TP": take_profit_price,
            })

    if events:
        pos["protective_orders_status"] = "Submitted"
    elif not (pos.get("ibkr_stop_manual_override") or pos.get("ibkr_take_profit_manual_override")):
        pos["protective_orders_status"] = "Already protected"
    return events


def cancel_protective_orders(ib: IB, pos: dict) -> list[dict]:
    """Cancel local-position protective orders before Pulse submits its own exit."""
    wanted_ids = {
        _coerce_order_id(pos.get("ibkr_stop_order_id")),
        _coerce_order_id(pos.get("ibkr_take_profit_order_id")),
    }
    wanted_ids.update(_coerce_order_ids(pos.get("ibkr_stop_order_ids")))
    wanted_ids.update(_coerce_order_ids(pos.get("ibkr_take_profit_order_ids")))
    wanted_ids.discard(None)
    if not wanted_ids:
        return []

    events = []
    for trade in _open_sell_trades_for_position(ib, pos):
        order = getattr(trade, "order", None)
        if _order_id(order) not in wanted_ids:
            continue
        try:
            ib.cancelOrder(order)
            ib.sleep(0.2)
            events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "CANCEL_PROTECTION", "Order ID": _order_id(order)})
        except Exception as exc:
            events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "CANCEL_PROTECTION_FAILED", "Status": str(exc)})
    return events


def _position_matches_broker_position(pos: dict, broker_pos) -> bool:
    contract = getattr(broker_pos, "contract", None)
    if contract is None:
        return False

    pos_con_id = pos.get("con_id")
    broker_con_id = getattr(contract, "conId", None)
    if pos_con_id and broker_con_id and int(pos_con_id) == int(broker_con_id):
        return True

    right = "C" if str(pos.get("signal", "")).upper() == "CALL" else "P"
    return (
        str(getattr(contract, "symbol", "")).upper() == str(pos.get("symbol", "")).upper()
        and str(getattr(contract, "lastTradeDateOrContractMonth", "")) == str(pos.get("expiry", ""))
        and float(getattr(contract, "strike", 0) or 0) == float(pos.get("strike", 0) or 0)
        and str(getattr(contract, "right", "")).upper() == right
    )


def portfolio_market_snapshot_for_position(
    portfolio_items: list,
    pos: dict,
    account: str | None = None,
) -> dict:
    """Return IBKR's portfolio mark when a contract snapshot has no quote."""
    for item in portfolio_items or []:
        if account and getattr(item, "account", None) not in [None, "", account]:
            continue
        if not _position_matches_broker_position(pos, item):
            continue
        market_price = _finite_number(getattr(item, "marketPrice", None))
        if market_price is None or market_price <= 0:
            continue
        return {
            "Mid": market_price,
            "Last": market_price,
            "Portfolio Market Value": _finite_number(getattr(item, "marketValue", None)),
            "Portfolio Unrealized PnL": _finite_number(getattr(item, "unrealizedPNL", None)),
            "Quote Source": "IBKR portfolio mark",
        }
    return {}


def _latest_logged_exit_for_position(pos: dict) -> dict:
    if not os.path.exists(TRADE_LOG_FILE):
        return {}
    try:
        df = pd.read_csv(TRADE_LOG_FILE)
    except Exception:
        return {}
    if df.empty or "event" not in df.columns:
        return {}

    exits = df[df["event"].fillna("").astype(str).str.upper().eq("EXIT")].copy()
    if "source" in exits.columns:
        exits = exits[exits["source"].fillna("").astype(str).str.upper().isin(["IBKR_EXECUTION", "IBKR_FLEX"])]
    if exits.empty:
        return {}

    option = str(pos.get("option") or "")
    con_id = str(pos.get("con_id") or "")
    symbol = str(pos.get("symbol") or "").upper()
    mask = pd.Series(False, index=exits.index)
    if option and "option" in exits.columns:
        mask = mask | exits["option"].fillna("").astype(str).eq(option)
    if con_id and "con_id" in exits.columns:
        numeric_id = _finite_number(con_id)
        if numeric_id is not None:
            mask = mask | pd.to_numeric(exits["con_id"], errors="coerce").eq(numeric_id)
    if not option and not con_id and symbol and "symbol" in exits.columns:
        mask = mask | exits["symbol"].fillna("").astype(str).str.upper().eq(symbol)

    matches = exits[mask].copy()
    if matches.empty:
        return {}
    if "timestamp" in matches.columns:
        matches["_ts"] = pd.to_datetime(matches["timestamp"], errors="coerce", utc=True)
        entry_ts = pd.to_datetime(pos.get("entry_time") or pos.get("timestamp") or pos.get("opened_at"), errors="coerce", utc=True)
        if not pd.isna(entry_ts):
            matches = matches[matches["_ts"].isna() | (matches["_ts"] >= entry_ts)]
            if matches.empty:
                return {}
        matches = matches.sort_values("_ts", na_position="first")
    row = matches.iloc[-1].to_dict()
    return {str(k): v for k, v in row.items() if k != "_ts"}


def _infer_broker_close_reason(pos: dict, exit_price: float | None, fallback: str) -> str:
    if exit_price is None:
        return fallback
    stop_price = _number_or_none(pos.get("current_stop_price"))
    take_profit_price = _number_or_none(pos.get("take_profit_price"))
    if stop_price is not None and float(exit_price) <= float(stop_price) + 0.01:
        return "Protective stop filled"
    if take_profit_price is not None and float(exit_price) >= float(take_profit_price) - 0.01:
        return "Protective take profit filled"
    return fallback


def reconcile_active_positions_with_broker(ib: IB, account: str | None = None, log_closures: bool = True) -> list[dict]:
    """Remove or resize bot-managed positions that no longer exist at IBKR.

    This protects against duplicate exits when a user manually closes a bot
    position from TWS/IBKR before the dashboard or engine sees it.
    """
    local_positions = read_active_positions()
    if not local_positions:
        return []

    broker_positions = []
    for broker_pos in ib.positions():
        if account and getattr(broker_pos, "account", None) != account:
            continue
        try:
            if float(getattr(broker_pos, "position", 0) or 0) != 0:
                broker_positions.append(broker_pos)
        except Exception:
            continue

    reconciled = []
    events = []
    for pos in local_positions:
        entry_status = str(pos.get("entry_status", ""))
        if entry_status and not is_filled_order_status(entry_status):
            events.append({
                "Symbol": pos.get("symbol"),
                "Option": pos.get("option"),
                "Action": "REMOVED",
                "Reason": "Entry order was not filled",
                "Status": entry_status,
            })
            continue

        matches = [bp for bp in broker_positions if _position_matches_broker_position(pos, bp)]
        broker_qty = sum(float(getattr(bp, "position", 0) or 0) for bp in matches)
        local_qty = int(pos.get("quantity", 0) or 0)

        if broker_qty <= 0:
            logged_exit = _latest_logged_exit_for_position(pos)
            exit_price = _finite_number(logged_exit.get("exit_price"))
            entry_price = _finite_number(pos.get("entry_price"))
            realized_pnl = _finite_number(logged_exit.get("realized_pnl"))
            basis = str(logged_exit.get("pnl_basis") or "")
            if str(logged_exit.get("source") or "").upper() == "IBKR_FLEX":
                basis = "broker_net"
            if exit_price is None or realized_pnl is None or basis != "broker_net":
                reconciled.append(pos)
                pos["exit_pending"] = True
                events.append({"Symbol": pos.get("symbol"), "Action": "CLOSE_PENDING", "Status": "Awaiting broker execution and fee confirmation"})
                continue
            close_reason = str(pos.get("pending_exit_reason") or logged_exit.get("exit_reason") or "Broker position closed").strip()
            stop_ids = set(_coerce_order_ids(pos.get("ibkr_stop_order_ids")))
            stop_ids.update(_coerce_order_ids(pos.get("ibkr_stop_order_id")))
            filled_ids = set(_coerce_order_ids(logged_exit.get("broker_order_ids")))
            if not pos.get("pending_exit_reason") and stop_ids & filled_ids:
                close_reason = "Emergency stop filled" if pos.get("exit_evaluation_mode") == CANDLE_CLOSE_MODE else "Protective stop filled"
            matched_source = str(logged_exit.get("source") or "").strip()
            matched_external_id = str(logged_exit.get("external_id") or "").strip()
            close_classification = "external_close"
            if matched_source.upper() == "IBKR_EXECUTION":
                close_classification = "matched_ibkr_execution"
            elif close_reason in {"Protective stop filled", "Protective take profit filled"}:
                close_classification = "protective_order_likely_filled"
            events.append({
                "Symbol": pos.get("symbol"),
                "Option": pos.get("option"),
                "Action": "REMOVED",
                "Reason": close_reason,
                "Quantity": local_qty,
                "Entry": entry_price,
                "Current": exit_price,
                "P/L $": round(float(realized_pnl or 0.0), 2),
                "Status": "Closed manually or no broker position exists",
                "Close Confirmed": True,
                "pnl_basis": "broker_net",
            })
            if log_closures:
                log_trade({
                    "timestamp": datetime.now(EASTERN).isoformat(),
                    "event": "EXTERNAL_CLOSE",
                    "symbol": pos.get("symbol"),
                    "signal": pos.get("signal"),
                    "option": pos.get("option"),
                    "quantity": local_qty,
                    "exit_reason": close_reason,
                    "entry_price": pos.get("entry_price"),
                    "exit_price": exit_price,
                    "realized_pnl": round(float(realized_pnl or 0.0), 2),
                    "pnl_basis": "broker_net",
                    "status": "Closed manually or removed during broker reconciliation",
                    "source": "BROKER_RECONCILIATION",
                    "matched_exit_external_id": matched_external_id or None,
                    "matched_exit_source": matched_source or None,
                    "close_classification": close_classification,
                    "exec_ids": logged_exit.get("exec_ids"),
                    "broker_order_ids": logged_exit.get("broker_order_ids"),
                    "broker_perm_ids": logged_exit.get("broker_perm_ids"),
                    "broker_client_ids": logged_exit.get("broker_client_ids"),
                    "broker_order_refs": logged_exit.get("broker_order_refs"),
                    "broker_liquidation_flags": logged_exit.get("broker_liquidation_flags"),
                })
            continue

        if local_qty > 0 and broker_qty < local_qty:
            pos["quantity"] = int(abs(broker_qty))
            events.append({
                "Symbol": pos.get("symbol"),
                "Option": pos.get("option"),
                "Action": "RESIZED",
                "Reason": "IBKR position quantity is lower than bot record",
                "Local Qty": local_qty,
                "Broker Qty": int(abs(broker_qty)),
            })
        if pos.get("exit_pending") and not pos.get("pending_exit_order_ids") and not pos.get("pending_exit_reason"):
            # A transient empty broker-position snapshot must not freeze a
            # position that the next broker refresh confirms is still open.
            pos.pop("exit_pending", None)
        reconciled.append(pos)

    if len(reconciled) != len(local_positions) or events:
        write_active_positions(reconciled)
    return events


def submit_exit_order(
    ib: IB,
    pos: dict,
    exit_price: float | None,
    reason: str,
    account: str | None = None,
    use_market: bool = True,
):
    assert_position_exit_allowed(pos)
    contract = reconstruct_option_contract(pos)
    try:
        qualified = ib.qualifyContracts(contract)
        if qualified:
            contract = qualified[0]
    except Exception:
        pass

    qty = int(pos.get("quantity", 0))
    if qty <= 0:
        raise ValueError("No quantity to exit")

    cancel_protective_orders(ib, pos)
    trades = []
    pos["exit_pending"] = True
    pos["pending_exit_reason"] = reason
    pos["pending_exit_order_ids"] = []
    pos["pending_exit_requested_quantity"] = qty
    pos["pending_exit_submitted_quantity"] = 0
    for chunk_qty in _order_chunks(qty):
        order = MarketOrder("SELL", chunk_qty) if use_market else LimitOrder("SELL", chunk_qty, round(float(exit_price), 2))
        if account:
            order.account = account
        try:
            trade = ib.placeOrder(contract, order)
        except Exception:
            if not trades:
                pos.pop("exit_pending", None)
                pos.pop("pending_exit_reason", None)
                for key in list(pos):
                    if key.startswith("ibkr_stop_order") or key.startswith("ibkr_take_profit_order"):
                        pos.pop(key, None)
            raise
        trades.append(trade)
        pos["pending_exit_submitted_quantity"] += chunk_qty
        order_id = _order_id(getattr(trade, "order", None))
        if order_id is not None:
            pos["pending_exit_order_ids"].append(order_id)
        ib.sleep(1)

    # Submission is not settlement. Retain the position until execution sync
    # supplies the weighted fill and complete broker net P/L (including fees).
    pos["exit_pending"] = True
    pos["pending_exit_reason"] = reason
    pos["pending_exit_order_ids"] = [
        _order_id(getattr(trade, "order", None)) for trade in trades
        if _order_id(getattr(trade, "order", None)) is not None
    ]
    entry_price = float(pos.get("entry_price", 0))
    details = [trade_fill_details(trade, chunk) for trade, chunk in zip(trades, _order_chunks(qty))]
    filled_qty = sum(float(detail["filled_qty"]) for detail in details)
    priced = [detail for detail in details if detail["filled_qty"] and detail["avg_fill_price"]]
    priced_qty = sum(float(detail["filled_qty"]) for detail in priced)
    mark = None
    if filled_qty and priced_qty == filled_qty:
        mark = sum(float(detail["avg_fill_price"]) * float(detail["filled_qty"]) for detail in priced) / filled_qty
    realized_pnl = None

    log_trade({
        "timestamp": datetime.now(EASTERN).isoformat(),
        "event": "EXIT",
        "symbol": pos.get("symbol"),
        "signal": pos.get("signal"),
        "option": pos.get("option"),
        "quantity": qty,
        "exit_reason": reason,
        "entry_price": entry_price,
        "exit_price": round(mark, 4) if mark is not None else None,
        "realized_pnl": realized_pnl,
        "filled_quantity": filled_qty,
        "pnl_basis": "pending_broker",
        "status": ", ".join(str(getattr(trade.orderStatus, "status", "")) for trade in trades),
        "source": "PULSE_EXIT_ORDER",
        "con_id": pos.get("con_id"),
        "broker_order_ids": ",".join(str(_order_id(getattr(trade, "order", None))) for trade in trades if _order_id(getattr(trade, "order", None)) is not None),
        "broker_perm_ids": ",".join(
            str(getattr(getattr(trade, "order", None), "permId", ""))
            for trade in trades
            if getattr(getattr(trade, "order", None), "permId", None)
        ),
        "broker_client_ids": ",".join(
            str(getattr(getattr(trade, "order", None), "clientId", ""))
            for trade in trades
            if getattr(getattr(trade, "order", None), "clientId", None)
        ),
        "close_classification": "pulse_exit_order",
    })
    return trades[-1], realized_pnl


def manage_candle_close_position(ib, pos, contract, now_et, *, account,
                                 stop_loss_pct, breakeven_trigger_pct,
                                 trailing_trigger_pct, trailing_stop_pct,
                                 force_exit_enabled, force_exit_time,
                                 require_eod_exit_approval, allow_live_orders):
    """Evaluate virtual protection at completed closes, execute at today's market."""
    events = []
    if pos.get("exit_pending"):
        events.append({"Symbol": pos.get("symbol"), "Action": "EXIT_PENDING", "Status": "Exit submitted; awaiting broker confirmation"})
        return events
    reason = None
    if force_exit_enabled and now_et.time() >= force_exit_time:
        reason = "End-of-day forced exit"
    else:
        try:
            closes = completed_option_closes(ib, contract, pos, now_et)
        except Exception as exc:
            events.append({"Symbol": pos.get("symbol"), "Action": "CANDLE_DATA_UNAVAILABLE", "Status": str(exc)})
            return events
        for timestamp, close in closes:
            reason = evaluate_close(pos, close, timestamp,
                                    breakeven_trigger_pct=breakeven_trigger_pct,
                                    trailing_trigger_pct=trailing_trigger_pct,
                                    trailing_stop_pct=trailing_stop_pct)
            events.append({"Symbol": pos.get("symbol"), "Action": "OPTION_CANDLE_CLOSE", "Candle Close": timestamp.isoformat(), "Option Close": close, "Stop": pos["current_stop_price"], "Emergency Stop": pos["emergency_stop_price"], "Reason": reason})
            if reason:
                break
    if reason == "End-of-day forced exit" and require_eod_exit_approval:
        events.append({"Symbol": pos.get("symbol"), "Option": pos.get("option"), "Action": "EXIT_APPROVAL_REQUIRED", "Reason": reason, "Quantity": pos.get("quantity"), "Entry": pos.get("entry_price"), "Current": pos.get("current_price"), "Position": dict(pos)})
    elif reason and allow_live_orders:
        submit_exit_order(ib, pos, None, reason, account=account, use_market=True)
        events.append({"Symbol": pos.get("symbol"), "Action": "EXIT_PENDING", "Reason": reason, "Status": "Awaiting broker execution and fees"})
    elif reason:
        events.append({"Symbol": pos.get("symbol"), "Action": "EXIT_SIGNAL", "Reason": reason, "Status": "Trading disabled"})
    else:
        events.append({"Symbol": pos.get("symbol"), "Action": "HOLD", "Stop": pos["current_stop_price"], "Emergency Stop": pos["emergency_stop_price"]})
    return events


def exit_order_still_pending(ib, pos):
    """Avoid duplicate sells; permit protection to resume after a rejected exit."""
    if not pos.get("exit_pending"):
        return False
    wanted = set(_coerce_order_ids(pos.get("pending_exit_order_ids")))
    trades = [t for t in ib.trades() if _order_id(getattr(t, "order", None)) in wanted] if wanted else []
    terminal = {"Filled", "Cancelled", "ApiCancelled", "Inactive"}
    if len(trades) == len(wanted) and wanted:
        statuses = [str(t.orderStatus.status) for t in trades]
        filled = sum(float(getattr(t.orderStatus, "filled", 0) or 0) for t in trades)
        requested = float(pos.get("pending_exit_requested_quantity") or pos["quantity"])
        incomplete_submission = float(pos.get("pending_exit_submitted_quantity") or requested) < requested
        broker_remaining_confirmed = float(pos["quantity"]) <= requested - filled
        if all(s in terminal for s in statuses) and broker_remaining_confirmed and (any(s != "Filled" for s in statuses) or incomplete_submission):
            pos.pop("exit_pending", None)
            pos.pop("pending_exit_order_ids", None)
            pos.pop("pending_exit_reason", None)
            pos.pop("pending_exit_requested_quantity", None)
            pos.pop("pending_exit_submitted_quantity", None)
            # Our own cancellation is not a manual cancellation to preserve.
            for key in list(pos):
                if key.startswith("ibkr_stop_order") or key.startswith("ibkr_take_profit_order"):
                    pos.pop(key, None)
            return False
    return True


def add_active_position_from_entry(
    row: dict,
    option_full: dict,
    qty: int,
    entry_price: float,
    trade_status: str,
    ib: IB | None = None,
    account: str | None = None,
    stop_loss_pct: float = DEFAULT_STOP_LOSS_PCT,
    take_profit_pct: float = DEFAULT_TAKE_PROFIT_PCT,
    trailing_stop_pct: float = 0.0,
    trailing_from_entry: bool = False,
    fixed_take_profit_enabled: bool = True,
    entry_source: str | None = None,
    management_mode: str | None = None,
    exit_evaluation_mode: str = "snapshot",
):
    if not is_filled_order_status(trade_status):
        return None

    contract = option_full["Contract"]
    positions = read_active_positions()
    position_id = f"{row['Symbol']}-{option_full['Expiry']}-{option_full['Strike']}-{option_full['Type']}-{datetime.now(EASTERN).strftime('%Y%m%d%H%M%S')}"
    monitor_only = (
        str(management_mode or "").strip().lower() == POSITION_MANAGEMENT_MONITOR_ONLY
        or str(entry_source or "").strip().lower() == MANUAL_ORDER_SOURCE
    )
    initial_stop_pct = float(trailing_stop_pct) if trailing_from_entry and float(trailing_stop_pct or 0) > 0 else float(stop_loss_pct)
    underlying_entry_price = _number_or_none(row.get("Price") or row.get("price"))
    if underlying_entry_price is None and ib is not None:
        underlying_entry_price = _number_or_none(get_stock_snapshot_price(ib, str(row.get("Symbol") or "")))
    position = {
        "id": position_id,
        "symbol": row["Symbol"],
        "signal": row["Signal"],
        "option": option_full["Option"],
        "expiry": option_full["Expiry"],
        "strike": float(option_full["Strike"]),
        "con_id": getattr(contract, "conId", None),
        "quantity": int(qty),
        "entry_price": round(float(entry_price), 2),
        "underlying_entry_price": underlying_entry_price,
        "current_stop_price": None if monitor_only else round(float(entry_price) * (1 - initial_stop_pct / 100), 2),
        "take_profit_price": None if monitor_only else round(float(entry_price) * (1 + float(take_profit_pct) / 100), 2),
        "take_profit_pct": round(float(take_profit_pct), 4),
        "highest_price": round(float(entry_price), 2),
        "breakeven_active": False,
        "trailing_active": False if monitor_only else bool(trailing_from_entry),
        "trailing_from_entry": False if monitor_only else bool(trailing_from_entry),
        "entry_time": datetime.now(EASTERN).isoformat(),
        "entry_status": trade_status,
        "entry_source": entry_source,
        "management_mode": POSITION_MANAGEMENT_MONITOR_ONLY if monitor_only else POSITION_MANAGEMENT_AUTOMATED,
        "software_control_enabled": not monitor_only,
        "protective_orders_status": "Monitor only - no PulseTrade exit orders" if monitor_only else "Not checked",
    }
    configure_option_exit_mode(position, exit_evaluation_mode, stop_loss_pct)
    if ib is not None and not monitor_only:
        ensure_protective_orders(
            ib,
            position,
            account=account,
            stop_loss_pct=stop_loss_pct,
            take_profit_pct=take_profit_pct,
            fixed_take_profit_enabled=fixed_take_profit_enabled,
        )
    positions.append(position)
    write_active_positions(positions)
    return position


def manage_open_positions(
    ib: IB,
    account: str | None,
    stop_loss_pct: float,
    take_profit_pct: float,
    breakeven_trigger_pct: float,
    trailing_trigger_pct: float,
    trailing_stop_pct: float,
    force_exit_time: dtime,
    allow_live_orders: bool,
    force_exit_enabled: bool = True,
    require_eod_exit_approval: bool = True,
    trailing_from_entry: bool = False,
    fixed_take_profit_enabled: bool = True,
    exit_evaluation_mode: str = "snapshot",
) -> list[dict]:
    """Manage active option positions across Streamlit refresh cycles."""
    positions = read_active_positions()
    if not positions:
        return []

    reconciliation_events = reconcile_active_positions_with_broker(ib, account=account, log_closures=True)
    positions = read_active_positions()
    if not positions:
        return reconciliation_events

    now_et = datetime.now(EASTERN)
    still_active = []
    events = list(reconciliation_events)
    try:
        portfolio_items = list(ib.portfolio() or [])
    except Exception:
        portfolio_items = []

    for pos in positions:
        try:
            if is_prior_session_position(pos, now_et):
                pos["exit_management_status"] = "Prior-session holding - automated exits disabled"
                still_active.append(pos)
                events.append({"Symbol": pos.get("symbol"), "Action": "PRIOR_SESSION_MONITOR_ONLY",
                               "Reason": "Prior-session holding; existing broker orders left unchanged"})
                continue
            monitor_only = is_monitor_only_position(pos)
            configure_option_exit_mode(pos, exit_evaluation_mode, stop_loss_pct)
            if not monitor_only and exit_order_still_pending(ib, pos):
                still_active.append(pos)
                events.append({"Symbol": pos.get("symbol"), "Action": "EXIT_PENDING", "Status": "Awaiting broker execution and fee confirmation"})
                continue
            if monitor_only:
                if account:
                    pos["account"] = account
                if allow_live_orders:
                    events.extend(disable_manual_position_exits(ib, pos))
                else:
                    pos.update(management_mode=POSITION_MANAGEMENT_MONITOR_ONLY,
                               software_control_enabled=False, current_stop_price=None,
                               take_profit_price=None, breakeven_active=False,
                               trailing_active=False, trailing_from_entry=False)
            contract = reconstruct_option_contract(pos)
            qualified = ib.qualifyContracts(contract)
            if qualified:
                contract = qualified[0]
                pos["con_id"] = getattr(contract, "conId", pos.get("con_id"))
            if allow_live_orders and not monitor_only:
                protection_events = ensure_protective_orders(
                    ib,
                    pos,
                    account=account,
                    stop_loss_pct=stop_loss_pct,
                    take_profit_pct=take_profit_pct,
                    fixed_take_profit_enabled=fixed_take_profit_enabled,
                )
                events.extend(protection_events)
            market = get_snapshot_mid(ib, contract)
            snapshot_mid = _finite_number(market.get("Mid"))
            if snapshot_mid is None or snapshot_mid <= 0:
                portfolio_market = portfolio_market_snapshot_for_position(portfolio_items, pos, account=account)
                if portfolio_market:
                    market = {**market, **portfolio_market}
            current_price = record_position_market_snapshot(pos, market, now_et)
            if not monitor_only and exit_evaluation_mode == CANDLE_CLOSE_MODE:
                events.extend(manage_candle_close_position(
                    ib, pos, contract, now_et, account=account, stop_loss_pct=stop_loss_pct,
                    breakeven_trigger_pct=breakeven_trigger_pct, trailing_trigger_pct=trailing_trigger_pct,
                    trailing_stop_pct=trailing_stop_pct, force_exit_enabled=force_exit_enabled,
                    force_exit_time=force_exit_time, require_eod_exit_approval=require_eod_exit_approval,
                    allow_live_orders=allow_live_orders))
                still_active.append(pos)
                continue
            if current_price is None:
                still_active.append(pos)
                events.append({"Symbol": pos.get("symbol"), "Status": "No option price available", "Action": "Hold"})
                continue

            entry_price = float(pos["entry_price"])
            pnl_pct = ((current_price - entry_price) / entry_price) * 100
            if monitor_only:
                still_active.append(pos)
                events.append({
                    "Symbol": pos.get("symbol"),
                    "Option": pos.get("option"),
                    "Action": "MONITOR_ONLY",
                    "Reason": "Manual order; PulseTrade exit controls disabled",
                    "Entry": entry_price,
                    "Current": round(current_price, 2),
                    "P/L %": round(pnl_pct, 1),
                })
                continue

            highest = max(float(pos.get("highest_price", entry_price)), current_price)
            pos["highest_price"] = round(highest, 2)

            stop_price = float(pos.get("current_stop_price", entry_price * (1 - stop_loss_pct / 100)))
            take_profit_price = float(pos.get("take_profit_price", entry_price * (1 + take_profit_pct / 100)))
            reason = None

            premium_health_events = evaluate_premium_health(ib, pos, current_price, now_et)
            events.extend(premium_health_events)
            stop_price = float(pos.get("current_stop_price", stop_price))

            if trailing_from_entry and not bool(pos.get("trailing_active", False)) and float(trailing_stop_pct or 0) > 0:
                pos["trailing_active"] = True
                pos["trailing_from_entry"] = True

            # Force flat before close. This exits winners and losers that did not hit TP/SL.
            if force_exit_enabled and now_et.time() >= force_exit_time:
                reason = "End-of-day forced exit"

            # Initial hard stop.
            elif current_price <= stop_price:
                reason = "Trailing stop hit" if pos.get("trailing_active") else "Breakeven stop hit" if pos.get("breakeven_active") else "Stop loss hit"

            # At +15%, move stop to breakeven.
            elif pnl_pct >= breakeven_trigger_pct and not bool(pos.get("breakeven_active", False)):
                pos["current_stop_price"] = round(entry_price, 2)
                pos["breakeven_active"] = True
                stop_price = entry_price

            # At +25%, activate trailing stop and cancel the fixed TP behavior.
            if reason is None and pnl_pct >= trailing_trigger_pct:
                pos["trailing_active"] = True
                trail_stop = highest * (1 - trailing_stop_pct / 100)
                pos["current_stop_price"] = round(max(float(pos.get("current_stop_price", stop_price)), trail_stop), 2)
                stop_price = float(pos["current_stop_price"])

            if reason is None and allow_live_orders:
                protection_events = ensure_protective_orders(
                    ib,
                    pos,
                    account=account,
                    stop_loss_pct=stop_loss_pct,
                    take_profit_pct=take_profit_pct,
                    fixed_take_profit_enabled=fixed_take_profit_enabled,
                )
                events.extend(protection_events)

            # Fixed take-profit is optional. When trailing is the exit model, winners are uncapped.
            if reason is None and fixed_take_profit_enabled and not bool(pos.get("trailing_active", False)) and current_price >= take_profit_price:
                reason = "Take profit hit"

            # Once trailing is active, exit only on trailing stop or EOD.
            if reason is None and bool(pos.get("trailing_active", False)) and current_price <= stop_price:
                reason = "Trailing stop hit"

            if reason:
                if reason == "End-of-day forced exit" and require_eod_exit_approval:
                    still_active.append(pos)
                    events.append({
                        "Symbol": pos.get("symbol"),
                        "Option": pos.get("option"),
                        "Action": "EXIT_APPROVAL_REQUIRED",
                        "Reason": reason,
                        "Quantity": pos.get("quantity"),
                        "Entry": entry_price,
                        "Current": round(current_price, 2),
                        "P/L %": round(pnl_pct, 1),
                        "Position": dict(pos),
                    })
                    continue
                if allow_live_orders:
                    if pos.get("exit_pending"):
                        still_active.append(pos)
                        continue
                    trade, realized = submit_exit_order(ib, pos, current_price, reason, account=account, use_market=True)
                    still_active.append(pos)
                    events.append({"Symbol": pos.get("symbol"), "Action": "EXIT_PENDING", "Reason": reason, "Status": str(trade.orderStatus.status)})
                    continue
                else:
                    realized = round((current_price - entry_price) * int(pos.get("quantity", 0)) * 100, 2)
                    status = "Exit signal only / trading disabled"
                events.append({
                    "Symbol": pos.get("symbol"),
                    "Option": pos.get("option"),
                    "Action": "EXIT",
                    "Reason": reason,
                    "Quantity": pos.get("quantity"),
                    "Entry": entry_price,
                    "Current": round(current_price, 2),
                    "P/L %": round(pnl_pct, 1),
                    "P/L $": realized,
                    "Status": status,
                })
            else:
                still_active.append(pos)
                events.append({
                    "Symbol": pos.get("symbol"),
                    "Option": pos.get("option"),
                    "Action": "HOLD",
                    "Entry": entry_price,
                    "Current": round(current_price, 2),
                    "P/L %": round(pnl_pct, 1),
                    "Stop": round(float(pos.get("current_stop_price", stop_price)), 2),
                    "TP": round(take_profit_price, 2),
                    "BE Active": bool(pos.get("breakeven_active", False)),
                    "Trailing Active": bool(pos.get("trailing_active", False)),
                })
        except Exception as e:
            still_active.append(pos)
            events.append({"Symbol": pos.get("symbol"), "Action": "ERROR", "Status": str(e)})

    write_active_positions(still_active)
    return events


# =========================
# CHART
# =========================

def make_chart(symbol: str, breakdown: dict):
    df = breakdown["Intraday Data"].copy()
    intraday_dates = sorted(set(df.index.date))
    if len(intraday_dates) >= 2:
        keep_from = intraday_dates[-2]
        df = df[df.index.date >= keep_from]

    fig = go.Figure()
    fig.add_trace(go.Candlestick(
        x=df.index,
        open=df["Open"],
        high=df["High"],
        low=df["Low"],
        close=df["Close"],
        name=symbol,
    ))
    fig.add_trace(go.Scatter(x=df.index, y=df["VWAP"], mode="lines", name="VWAP"))
    fig.add_hline(y=breakdown["ORB High"], line_dash="dash", line_color="yellow", annotation_text="ORB High")
    fig.add_hline(y=breakdown["ORB Low"], line_dash="dash", line_color="yellow", annotation_text="ORB Low")
    fig.add_hline(y=breakdown["PDH"], line_dash="dot", line_color="red", annotation_text="PDH")
    fig.add_hline(y=breakdown["PDL"], line_dash="dot", line_color="red", annotation_text="PDL")
    if breakdown.get("Nearest Support"):
        fig.add_hline(y=breakdown["Nearest Support"], line_dash="dot", line_color="green", annotation_text="Support")
    if breakdown.get("Nearest Resistance"):
        fig.add_hline(y=breakdown["Nearest Resistance"], line_dash="dot", line_color="orange", annotation_text="Resistance")
    fig.update_layout(height=600, xaxis_rangeslider_visible=False, title=f"{symbol} 5m Chart")
    fig.update_xaxes(rangebreaks=[dict(bounds=[16, 9.5], pattern="hour"), dict(bounds=["sat", "mon"])])
    return fig



def summarize_trade_log() -> dict:
    """Return simple performance summary from exports/trade_log.csv."""
    if not os.path.exists(TRADE_LOG_FILE):
        return {
            "total_entries": 0,
            "total_exits": 0,
            "realized_pnl": 0.0,
            "wins": 0,
            "losses": 0,
            "win_rate": 0.0,
        }
    try:
        df = pd.read_csv(TRADE_LOG_FILE)
        if df.empty:
            return {
                "total_entries": 0,
                "total_exits": 0,
                "realized_pnl": 0.0,
                "wins": 0,
                "losses": 0,
                "win_rate": 0.0,
            }
        events = df.get("event", pd.Series([], dtype=str)).fillna("").astype(str)
        exits = df[events == "EXIT"].copy()
        pnl = pd.to_numeric(exits.get("realized_pnl", 0), errors="coerce").fillna(0)
        wins = int((pnl > 0).sum())
        losses = int((pnl < 0).sum())
        total_exits = int(len(exits))
        return {
            "total_entries": int((events == "ENTRY").sum()),
            "total_exits": total_exits,
            "realized_pnl": round(float(pnl.sum()), 2),
            "wins": wins,
            "losses": losses,
            "win_rate": round((wins / total_exits * 100), 1) if total_exits else 0.0,
        }
    except Exception:
        return {
            "total_entries": 0,
            "total_exits": 0,
            "realized_pnl": 0.0,
            "wins": 0,
            "losses": 0,
            "win_rate": 0.0,
        }


def make_equity_curve_chart():
    """Build a simple realized P/L equity curve from closed trades."""
    if not os.path.exists(TRADE_LOG_FILE):
        return None
    try:
        df = pd.read_csv(TRADE_LOG_FILE)
        if df.empty or "event" not in df.columns or "realized_pnl" not in df.columns:
            return None
        df = df[df["event"].astype(str) == "EXIT"].copy()
        if df.empty:
            return None
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
        df = df.dropna(subset=["timestamp"]).sort_values("timestamp")
        df["realized_pnl"] = pd.to_numeric(df["realized_pnl"], errors="coerce").fillna(0)
        df["cumulative_pnl"] = df["realized_pnl"].cumsum()
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df["timestamp"], y=df["cumulative_pnl"], mode="lines+markers", name="Cumulative P/L"))
        fig.update_layout(height=420, title="Realized P/L Equity Curve", xaxis_title="Time", yaxis_title="Realized P/L USD")
        return fig
    except Exception:
        return None


def make_trade_pnl_bar_chart():
    """Build a per-trade realized P/L bar chart from closed trades."""
    if not os.path.exists(TRADE_LOG_FILE):
        return None
    try:
        df = pd.read_csv(TRADE_LOG_FILE)
        if df.empty or "event" not in df.columns or "realized_pnl" not in df.columns:
            return None
        df = df[df["event"].astype(str) == "EXIT"].copy()
        if df.empty:
            return None
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
        df = df.dropna(subset=["timestamp"]).sort_values("timestamp")
        df["realized_pnl"] = pd.to_numeric(df["realized_pnl"], errors="coerce").fillna(0)
        labels = df.get("symbol", pd.Series(range(len(df)))).astype(str) + " " + df["timestamp"].dt.strftime("%m-%d %H:%M")
        fig = go.Figure()
        fig.add_trace(go.Bar(x=labels, y=df["realized_pnl"], name="Trade P/L"))
        fig.update_layout(height=420, title="Closed Trade P/L", xaxis_title="Trade", yaxis_title="P/L USD")
        return fig
    except Exception:
        return None

# =========================
# UI HELPERS
# =========================

def signal_badge(signal: str) -> str:
    if signal == "CALL":
        return "🟢 CALL"
    if signal == "PUT":
        return "🔴 PUT"
    return "⚪ WAIT"


def is_top_candidate(
    result: dict,
    min_score: float,
    min_confidence: float,
    min_rvol: float,
    min_atr: float,
    use_rvol_filter: bool,
    use_sr_filter: bool = False,
    min_sr_room_pct: float = 0.75,
) -> bool:
    """Filter live candidates.

    PMB v2 uses Score + Grade as the trade-quality filter. The min_confidence
    argument remains in the function signature so older dashboard/engine calls
    do not break, but it is intentionally ignored.
    """
    if not result or result.get("Signal") not in ["CALL", "PUT"]:
        return False
    try:
        if float(result.get("Score", 0)) < float(min_score):
            return False
        if bool(use_rvol_filter) and float(result.get("RVOL", 0)) < float(min_rvol):
            return False
        if float(result.get("ATR %", 0)) < float(min_atr):
            return False
        if bool(use_sr_filter):
            room_ok, room_pct, room_note = setup_room_check(result, float(min_sr_room_pct))
            result["Room To Move %"] = round(room_pct, 2) if room_pct is not None else None
            result["Room Check"] = room_note
            if not room_ok:
                return False
    except Exception:
        return False
    return True


def clean_for_table(result: dict) -> dict:
    row = result.copy()
    row.pop("Intraday Data", None)
    return row


def make_alert_message(result: dict, option: dict | None) -> str:
    text = (
        f"<b>{result['Symbol']} {result['Signal']} setup</b>\n"
        f"Score: {result['Score']} | Grade: {result.get('Grade', 'N/A')} | Quality: {result.get('Setup Quality', 'N/A')}\n"
        f"Price: ${result['Price']} | RVOL: {result['RVOL']} | ATR%: {result['ATR %']}\n"
        f"VWAP: {result['VWAP']} | ORB: {result['ORB High']} / {result['ORB Low']}\n"
        f"PDH/PDL: {result['PDH']} / {result['PDL']}\n"
        f"ORB confirmed: {result.get('ORB Confirmation Close', 'N/A')} at {result.get('ORB Confirmation Time', 'N/A')}\n"
        f"Retest: {result.get('Retest Reason', 'N/A')} | Trigger: {result.get('Retest Trigger Level', 'N/A')}\n"
        f"Support/Resistance: {result.get('Nearest Support', 'N/A')} / {result.get('Nearest Resistance', 'N/A')}\n"
        f"Room check: {result.get('Room Check', 'N/A')}\n"
        f"Why: {result['Reasons']}"
    )
    if option:
        text += (
            f"\n\n<b>Option</b>: {option['Option']}\n"
            f"Mid: ${option['Mid']} | Bid/Ask: {option['Bid']} / {option['Ask']}\n"
            f"Spread: {option.get('Spread %', 'N/A')}% | Delta: {option.get('Delta', 'N/A')} | Theta: {option.get('Theta', 'N/A')} | IV: {option.get('Implied Vol', 'N/A')}\n"
            f"Option score: {option.get('Option Score', 'N/A')} | {option.get('Option Score Notes', '')}\n"
            f"Risk/Contract: ${option['Risk / Contract']}"
        )
    return text




# =========================
# PRODUCTION HELPERS
# =========================
from pathlib import Path as _Path
import logging as _logging

BASE_DIR = _Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
HEALTH_FILE = LOG_DIR / "health.json"
DAILY_LOG_FILE = LOG_DIR / f"{datetime.now(EASTERN).date()}.log"

# Override relative export files so dashboard and engine use the same folder everywhere.
EXPORT_DIR = str(BASE_DIR / "exports")
os.makedirs(EXPORT_DIR, exist_ok=True)
TRADE_LOG_FILE = os.path.join(EXPORT_DIR, "trade_log.csv")
ALERT_LOG_FILE = os.path.join(EXPORT_DIR, "alert_log.csv")
ACTIVE_POSITIONS_FILE = os.path.join(EXPORT_DIR, "active_positions.json")


def deep_merge(default: dict, override: dict) -> dict:
    out = dict(default)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def default_config() -> dict:
    return {
        "account_mode": "Simulation",
        "ib": {"host": "127.0.0.1", "paper_port": 7497, "live_port": 7496, "client_id": 11, "account": "", "readonly": False},
        "telegram": {"bot_token": "", "chat_id": "", "send_alerts": False},
        "automation": {"enabled": False, "place_orders": False, "confirm_order_risk": False, "approval_mode": "Dashboard", "require_trade_approval": False, "live_confirm_text": "", "scan_interval_seconds": 300, "align_scans_to_interval": True, "first_scan_hour": 9, "first_scan_minute": 50, "live_sync_interval_seconds": 15, "market_timezone": "America/New_York", "scan_only_market_hours": True},
        "staged_trading_timeline": {"enabled": False, "opening_start_hour": 9, "opening_start_minute": 35, "opening_end_hour": 9, "opening_end_minute": 45, "midday_end_hour": 11, "midday_end_minute": 30, "retest_end_hour": 13, "retest_end_minute": 30, "opening_scan_interval_seconds": 60, "orb_scan_interval_seconds": 300, "retest_scan_interval_seconds": 300},
        "opening_orb_trade": {"enabled": False, "start_hour": 9, "start_minute": 35, "end_hour": 9, "end_minute": 45, "orb_minutes": 5, "capital_pct": 50.0, "scan_interval_seconds": 30, "min_score": 94.0, "min_rvol": 1.5, "stop_loss_pct": 5.0},
        "strategy": {"option_dte": 7, "min_score": 70, "min_confidence": 0, "use_rvol_filter": False, "min_rvol": 1.5, "use_rvol_score": False, "use_rvol_ranking": False, "use_sr_filter": True, "min_sr_room_pct": 0.75, "min_atr": 0.3, "top_n_tickers": 2, "active_strategy": "pmb", "orb_minutes": 15, "first_signal_minutes": 20, "min_session_bars": 7, "require_break_retest": False, "retest_tolerance_pct": 0.10, "retest_max_minutes": 45},
        "risk": {"account_size": 1000, "use_ibkr_buying_power": False, "max_trades_per_day": 2, "allow_same_symbol_same_day": False, "recycle_capital_after_exit": False, "count_prior_day_positions_in_allocation": True, "reserve_capital_for_remaining_trades": True, "max_spend_per_trade_pct": 20.0, "max_daily_capital_pct": 35.0, "max_spend_per_trade": 200, "max_daily_capital": 350, "max_contracts": 5, "entry_cutoff_hour": 14, "entry_cutoff_minute": 30, "stop_loss_pct": 20.0, "take_profit_pct": 30.0, "breakeven_trigger_pct": 15.0, "trailing_from_entry": True, "trailing_trigger_pct": 25.0, "trailing_stop_pct": 10.0, "use_take_profit_with_trailing": False, "force_exit_enabled": True, "require_eod_exit_approval": True, "force_exit_hour": 15, "force_exit_minute": 55, "max_consecutive_losses": 2, "max_daily_drawdown_pct": 5.0},
        "order": {"type": "LIMIT"},
        "option_filters": dict(DEFAULT_OPTION_FILTERS),
        "watchlist": WATCHLIST,
        "dynamic_watchlist": {"enabled": True, "mode": "Automatic", "suggestive_only": True, "max_symbols": 8, "refresh_hour": 9, "refresh_minute": 35, "source_universe": WATCHLIST},
        "scanner": {"auto_run_enabled": True, "auto_run_hour": 9, "auto_run_minute": 40},
        "ibkr_flex": {"token": "", "trade_query_id": "", "base_url": ""},
        "performance": {"original_deposited_capital": 2300.0},
    }


def load_config(path: str | _Path = CONFIG_PATH) -> dict:
    path = _Path(path)
    if not path.exists():
        cfg = default_config()
        save_config(cfg, path)
        return cfg
    try:
        with path.open("r", encoding="utf-8") as f:
            return deep_merge(default_config(), json.load(f))
    except Exception:
        return default_config()


def save_config(config: dict, path: str | _Path = CONFIG_PATH) -> None:
    path = _Path(path)
    with path.open("w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def ib_port_from_config(config: dict) -> int:
    mode = config.get("account_mode", "Simulation")
    ib = config.get("ib", {})
    return int(ib.get("live_port", 7496) if mode == "Live" else ib.get("paper_port", 7497))


def orders_unlocked_from_config(config: dict) -> bool:
    """Return True only when all order-safety gates are open.

    Simulation never places IBKR orders.
    Paper requires automation, place-orders, and risk confirmation.
    Live requires the same gates plus the exact text phrase TRADE LIVE.
    """
    mode = config.get("account_mode", "Simulation")
    automation = config.get("automation", {})
    ib = config.get("ib", {})
    if mode not in ["Paper", "Live"]:
        return False
    if ib.get("readonly", False):
        return False
    if not automation.get("enabled", False):
        return False
    if not automation.get("place_orders", False):
        return False
    if not automation.get("confirm_order_risk", False):
        return False
    if mode == "Live" and str(automation.get("live_confirm_text", "")).strip().upper() != "TRADE LIVE":
        return False
    return True


def trading_status_from_config(config: dict) -> str:
    mode = config.get("account_mode", "Simulation")
    if mode == "Simulation":
        return "SIMULATION / NO ORDERS"
    if orders_unlocked_from_config(config):
        return f"{mode.upper()} ARMED"
    return f"{mode.upper()} SAFE / DISABLED"


def is_market_open_now(config: dict | None = None) -> bool:
    now = datetime.now(EASTERN)
    if now.weekday() >= 5:
        return False
    return dtime(9, 30) <= now.time() <= dtime(16, 0)


def write_health(**kwargs) -> None:
    data = read_health()
    data.update(kwargs)
    data["updated_at"] = datetime.now(EASTERN).isoformat()
    with HEALTH_FILE.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


def read_health() -> dict:
    if not HEALTH_FILE.exists():
        return {}
    try:
        with HEALTH_FILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def app_log(message: str, level: str = "INFO") -> None:
    line = f"{datetime.now(EASTERN).isoformat()} | {level} | {message}"
    print(line, flush=True)
    with DAILY_LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


# =========================
# TRADE REPLAY / JOURNAL HELPERS
# =========================
TRADE_REPLAY_FILE = os.path.join(EXPORT_DIR, "trade_replay.csv")
TRADE_SNAPSHOTS_DIR = os.path.join(EXPORT_DIR, "trade_snapshots")
os.makedirs(TRADE_SNAPSHOTS_DIR, exist_ok=True)


def _safe_replay_value(value):
    """Convert pandas/numpy/contract objects into CSV-safe values."""
    try:
        if isinstance(value, (pd.Timestamp, datetime)):
            return value.isoformat()
        if isinstance(value, (np.integer,)):
            return int(value)
        if isinstance(value, (np.floating,)):
            return float(value)
        if isinstance(value, (np.bool_,)):
            return bool(value)
        if isinstance(value, (dict, list, tuple)):
            return json.dumps(value, default=str)
        if hasattr(value, "conId"):
            return getattr(value, "conId", None)
        return value
    except Exception:
        return str(value)


def save_trade_replay(row: dict, option: dict | None = None, event: str = "SIGNAL", order_status: str = "", quantity: int = 0, entry_price: float | None = None, estimated_cost: float | None = None, notes: str = "") -> dict:
    """Persist the complete setup context for later review.

    This is intentionally independent from the broker order result. It records
    why the bot liked the setup: score, confidence, ORB/VWAP/PDH/PDL, option
    selected, risk sizing, and the status at that moment.
    """
    option = option or {}
    replay = {
        "timestamp": datetime.now(EASTERN).isoformat(),
        "event": event,
        "symbol": row.get("Symbol"),
        "signal": row.get("Signal"),
        "score": row.get("Score"),
        "confidence": row.get("Confidence"),
        "grade": row.get("Grade"),
        "setup_quality": row.get("Setup Quality"),
        "score_components": row.get("Score Components"),
        "bull_score": row.get("Bull Score"),
        "bear_score": row.get("Bear Score"),
        "rank_score": row.get("Rank Score"),
        "price": row.get("Price"),
        "rvol": row.get("RVOL"),
        "atr_pct": row.get("ATR %"),
        "vwap": row.get("VWAP"),
        "orb_high": row.get("ORB High"),
        "orb_low": row.get("ORB Low"),
        "orb_up": row.get("ORB Up"),
        "orb_down": row.get("ORB Down"),
        "orb_confirmation_close": row.get("ORB Confirmation Close"),
        "orb_confirmation_time": row.get("ORB Confirmation Time"),
        "retest_required": row.get("Retest Required"),
        "retest_confirmed": row.get("Retest Confirmed"),
        "retest_trigger_level": row.get("Retest Trigger Level"),
        "breakout_time": row.get("Breakout Time"),
        "retest_time": row.get("Retest Time"),
        "retest_minutes_after_breakout": row.get("Retest Minutes After Breakout"),
        "retest_reason": row.get("Retest Reason"),
        "pdh": row.get("PDH"),
        "pdl": row.get("PDL"),
        "pdh_break": row.get("PDH Break"),
        "pdl_break": row.get("PDL Break"),
        "above_vwap": row.get("Above VWAP"),
        "below_vwap": row.get("Below VWAP"),
        "ema_bullish": row.get("EMA Bullish"),
        "ema_bearish": row.get("EMA Bearish"),
        "nearest_support": row.get("Nearest Support"),
        "nearest_resistance": row.get("Nearest Resistance"),
        "reasons": row.get("Reasons"),
        "option": option.get("Option"),
        "expiry": option.get("Expiry"),
        "strike": option.get("Strike"),
        "type": option.get("Type"),
        "delta": option.get("Delta"),
        "estimated_delta": option.get("Estimated Delta"),
        "gamma": option.get("Gamma"),
        "theta": option.get("Theta"),
        "theta_pct_mid": option.get("Theta % Mid"),
        "vega": option.get("Vega"),
        "implied_vol": option.get("Implied Vol"),
        "greek_source": option.get("Greek Source"),
        "bid": option.get("Bid"),
        "ask": option.get("Ask"),
        "mid": option.get("Mid"),
        "spread_pct": option.get("Spread %"),
        "spread_dollars": option.get("Spread $"),
        "option_score": option.get("Option Score"),
        "option_score_notes": option.get("Option Score Notes"),
        "risk_per_contract": option.get("Risk / Contract"),
        "quantity": quantity,
        "entry_price": entry_price,
        "estimated_cost": estimated_cost,
        "order_status": order_status,
        "notes": notes,
    }
    replay = {k: _safe_replay_value(v) for k, v in replay.items()}
    df = pd.DataFrame([replay])
    exists = os.path.exists(TRADE_REPLAY_FILE)
    df.to_csv(TRADE_REPLAY_FILE, mode="a", index=False, header=not exists)

    try:
        replay_id = f"{replay.get('timestamp','')}_{replay.get('symbol','')}_{replay.get('signal','')}".replace(":", "-").replace("/", "-")
        snapshot_path = os.path.join(TRADE_SNAPSHOTS_DIR, f"{replay_id}.json")
        with open(snapshot_path, "w", encoding="utf-8") as f:
            json.dump(replay, f, indent=2, default=str)
        replay["snapshot_path"] = snapshot_path
    except Exception:
        pass
    return replay


def load_trade_replay() -> pd.DataFrame:
    if not os.path.exists(TRADE_REPLAY_FILE):
        return pd.DataFrame()
    try:
        df = pd.read_csv(TRADE_REPLAY_FILE)
        if "timestamp" in df.columns:
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
            df = df.dropna(subset=["timestamp"]).sort_values("timestamp", ascending=False)
        return df
    except Exception:
        return pd.DataFrame()


def setup_quality_label(score: float | int | None, confidence: float | int | None = None) -> str:
    """Return PMB v2 quality label from score only. Confidence is ignored."""
    try:
        score = float(score or 0)
        if score >= 95:
            return "A+ / Elite"
        if score >= 90:
            return "A / High quality"
        if score >= 85:
            return "A- / Strong"
        if score >= 80:
            return "B+ / Tradable"
        if score >= 75:
            return "B / Valid"
        if score >= 70:
            return "B- / Borderline"
        if score >= 60:
            return "C / Watch only"
        return "Ignore"
    except Exception:
        return "Watchlist"
    except Exception:
        return "Watchlist"
